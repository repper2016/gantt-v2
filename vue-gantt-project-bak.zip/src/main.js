import Vue from 'vue'
// 按需引入Element UI组件
import {
  Button,
  Select,
  Option,
  DatePicker,
  Dialog,
  Input,
  Form,
  FormItem,
  Table,
  TableColumn,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Message,
  MessageBox,
  Alert,
  Loading,
  Progress,
  Slider,
  Switch,
  Popover,
  Tooltip,
  ColorPicker,
  Checkbox,
  CheckboxGroup,
  Radio,
  RadioGroup
} from 'element-ui'

// 只引入需要的Element UI样式
import 'element-ui/lib/theme-chalk/button.css'
import 'element-ui/lib/theme-chalk/select.css'
import 'element-ui/lib/theme-chalk/date-picker.css'
import 'element-ui/lib/theme-chalk/dialog.css'
import 'element-ui/lib/theme-chalk/input.css'
import 'element-ui/lib/theme-chalk/form.css'
import 'element-ui/lib/theme-chalk/table.css'
import 'element-ui/lib/theme-chalk/dropdown.css'
import 'element-ui/lib/theme-chalk/loading.css'
import 'element-ui/lib/theme-chalk/progress.css'
import 'element-ui/lib/theme-chalk/slider.css'
import 'element-ui/lib/theme-chalk/switch.css'
import 'element-ui/lib/theme-chalk/popover.css'
import 'element-ui/lib/theme-chalk/tooltip.css'
import 'element-ui/lib/theme-chalk/color-picker.css'
import 'element-ui/lib/theme-chalk/checkbox.css'
import 'element-ui/lib/theme-chalk/radio.css'
import 'element-ui/lib/theme-chalk/base.css'
import 'element-ui/lib/theme-chalk/alert.css'
import 'element-ui/lib/theme-chalk/message.css'
import 'element-ui/lib/theme-chalk/message-box.css'

// 引入甘特图样式
import '@/styles/themes.css'
import '@/styles/themes-dhtmlx.css'
import '@/styles/performance.css'

// 功能配置
import { isDebuggingEnabled } from '@/config/features'

import App from './App.vue'
import router from './router'
import store from './store'

// 注册Element UI组件
Vue.use(Button)
Vue.use(Select)
Vue.use(Option)
Vue.use(DatePicker)
Vue.use(Dialog)
Vue.use(Input)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Dropdown)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(Alert)
Vue.use(Loading.directive)
Vue.use(Progress)
Vue.use(Slider)
Vue.use(Switch)
Vue.use(Popover)
Vue.use(Tooltip)
Vue.use(ColorPicker)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
Vue.use(Radio)
Vue.use(RadioGroup)

// 挂载全局方法
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$loading = Loading.service

Vue.config.productionTip = false

// 性能监控 - 仅在开发环境
if (process.env.NODE_ENV === 'development') {
  Vue.config.performance = true
}

// 错误处理 - 完全静默处理
Vue.config.errorHandler = (err, vm, info) => {
  // 静默处理错误，不输出到控制台
  // 在生产环境中可以将错误发送到日志服务
}

// 禁用所有 console 输出（如果调试被禁用）
if (!isDebuggingEnabled()) {
  const noop = () => {}
  console.log = noop
  console.warn = noop
  console.error = noop
  console.info = noop
  console.debug = noop
  console.trace = noop
}

// 创建Vue实例
const app = new Vue({
  router,
  store,
  render: h => h(App)
})

// 挂载应用
app.$mount('#app')

// 导出应用实例用于测试
export default app
