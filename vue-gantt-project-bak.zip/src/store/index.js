import Vue from 'vue'
import Vuex from 'vuex'
import moment from 'moment'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    timelineData: [
      {
        id: 1,
        title: 'Project Planning',
        date: '2024-01-01',
        content: 'Initial project planning and requirements analysis'
      },
      {
        id: 2,
        title: 'Design Phase',
        date: '2024-01-15',
        content: 'UI/UX design and architecture planning'
      },
      {
        id: 3,
        title: 'Development Start',
        date: '2024-02-01',
        content: 'Core development and implementation'
      },
      {
        id: 4,
        title: 'Testing Phase',
        date: '2024-03-01',
        content: 'QA testing and bug fixes'
      },
      {
        id: 5,
        title: 'Launch Ready',
        date: '2024-03-15',
        content: 'Production deployment and launch'
      }
    ],
    ganttData: [
      {
        id: 1,
        name: 'Project Management',
        children: [
          {
            id: 11,
            name: 'Project Planning',
            startDate: '2024-01-01',
            endDate: '2024-01-15',
            planStartDate: '2023-12-28',
            planEndDate: '2024-01-12',
            progress: 100,
            color: '#3498db',
            milestone: true,
            // 权限控制：每行都需要有编辑权限控制
            permissions: {
              editable: true,
              deletable: true,
              movable: true
            }
          },
          {
            id: 12,
            name: 'Requirements Analysis',
            startDate: '2024-01-10',
            endDate: '2024-01-25',
            planStartDate: '2024-01-08',
            planEndDate: '2024-01-22',
            progress: 90,
            color: '#2ecc71',
            // 权限控制：每行都需要有编辑权限控制
            permissions: {
              editable: true,
              deletable: true,
              movable: true
            }
          },
          {
            id: 13,
            name: 'Project Documentation',
            startDate: '2024-01-20',
            endDate: '2024-02-05',
            planStartDate: '2024-01-18',
            planEndDate: '2024-02-01',
            progress: 75,
            color: '#f39c12',
            // 权限控制：每行都需要有编辑权限控制
            permissions: {
              editable: true,
              deletable: true,
              movable: true
            }
          }
        ]
      },
      {
        id: 2,
        name: 'Design & Development',
        children: [
          {
            id: 21,
            name: 'UI/UX Design',
            startDate: '2024-01-15',
            endDate: '2024-02-10',
            planStartDate: '2024-01-12',
            planEndDate: '2024-02-08',
            progress: 85,
            color: '#e74c3c',
            // 权限控制：每行都需要有编辑权限控制
            permissions: {
              editable: true,
              deletable: true,
              movable: true
            }
          },
          {
            id: 22,
            name: 'Frontend Development',
            startDate: '2024-02-01',
            endDate: '2024-03-15',
            planStartDate: '2024-01-30',
            planEndDate: '2024-03-10',
            progress: 65,
            color: '#9b59b6'
          },
          {
            id: 23,
            name: 'Backend Development',
            startDate: '2024-02-05',
            endDate: '2024-03-20',
            planStartDate: '2024-02-01',
            planEndDate: '2024-03-15',
            progress: 50,
            color: '#1abc9c'
          },
          {
            id: 24,
            name: 'Database Design',
            startDate: '2024-01-25',
            endDate: '2024-02-15',
            planStartDate: '2024-01-22',
            planEndDate: '2024-02-12',
            progress: 95,
            color: '#34495e'
          }
        ]
      },
      {
        id: 3,
        name: 'Testing & Quality Assurance',
        children: [
          {
            id: 31,
            name: 'Unit Testing',
            startDate: '2024-02-20',
            endDate: '2024-03-10',
            planStartDate: '2024-02-18',
            planEndDate: '2024-03-08',
            progress: 40,
            color: '#e67e22'
          },
          {
            id: 32,
            name: 'Integration Testing',
            startDate: '2024-03-01',
            endDate: '2024-03-25',
            planStartDate: '2024-02-28',
            planEndDate: '2024-03-22',
            progress: 20,
            color: '#8e44ad'
          },
          {
            id: 33,
            name: 'User Acceptance Testing',
            startDate: '2024-03-15',
            endDate: '2024-04-05',
            planStartDate: '2024-03-12',
            planEndDate: '2024-04-02',
            progress: 0,
            color: '#16a085'
          }
        ]
      },
      {
        id: 4,
        name: 'Deployment & Launch',
        children: [
          {
            id: 41,
            name: 'Production Setup',
            startDate: '2024-03-20',
            endDate: '2024-04-01',
            planStartDate: '2024-03-18',
            planEndDate: '2024-03-30',
            progress: 0,
            color: '#c0392b'
          },
          {
            id: 42,
            name: 'Go Live',
            startDate: '2024-04-01',
            endDate: '2024-04-01',
            planStartDate: '2024-03-31',
            planEndDate: '2024-03-31',
            progress: 0,
            color: '#27ae60',
            milestone: true
          },
          {
            id: 43,
            name: 'Project Completion Milestone',
            startDate: '2024-04-05',
            endDate: '2024-04-05',
            planStartDate: '2024-04-05',
            planEndDate: '2024-04-05',
            progress: 0,
            color: '#e74c3c',
            milestone: true,
            description: 'Major milestone marking project completion',
            priority: 'critical',
            assignee: 'Project Manager',
            taskType: 'Milestone'
          }
        ]
      },
      {
        id: 5,
        name: 'Multi-Task Testing Group',
        color: '#ff6b6b',
        children: [
          {
            id: 51,
            name: 'Task A - Overlapping Period',
            startDate: '2024-02-01',
            endDate: '2024-02-15',
            planStartDate: '2024-01-30',
            planEndDate: '2024-02-12',
            progress: 80,
            color: '#4ecdc4'
          },
          {
            id: 52,
            name: 'Task B - Same Period',
            startDate: '2024-02-01',
            endDate: '2024-02-10',
            planStartDate: '2024-01-29',
            planEndDate: '2024-02-08',
            progress: 60,
            color: '#45b7d1'
          },
          {
            id: 53,
            name: 'Task C - Partial Overlap',
            startDate: '2024-02-05',
            endDate: '2024-02-20',
            planStartDate: '2024-02-03',
            planEndDate: '2024-02-18',
            progress: 40,
            color: '#96ceb4'
          },
          {
            id: 54,
            name: 'Task D - Sequential',
            startDate: '2024-02-16',
            endDate: '2024-02-28',
            planStartDate: '2024-02-14',
            planEndDate: '2024-02-26',
            progress: 20,
            color: '#feca57'
          },
          {
            id: 55,
            name: 'Task E - Long Duration',
            startDate: '2024-01-25',
            endDate: '2024-03-05',
            planStartDate: '2024-01-23',
            planEndDate: '2024-03-03',
            progress: 90,
            color: '#ff9ff3'
          }
        ]
      }
    ],
    dependencies: [
      { from: 11, to: 21, color: '#3498db' }, // Planning -> UI Design
      { from: 12, to: 24, color: '#9b59b6' }, // Requirements -> Database Design
      { from: 21, to: 22, color: '#2ecc71' }, // UI Design -> Frontend
      { from: 24, to: 23, color: '#e74c3c' }, // Database -> Backend
      { from: 22, to: 31, color: '#f39c12' }, // Frontend -> Unit Testing
      { from: 23, to: 32, color: '#1abc9c' }, // Backend -> Integration Testing
      { from: 31, to: 33, color: '#34495e' }, // Unit -> UAT
      { from: 32, to: 33, color: '#e67e22' }, // Integration -> UAT
      { from: 33, to: 41, color: '#8e44ad' }, // UAT -> Production Setup
      { from: 41, to: 42, color: '#27ae60' }, // Production -> Go Live
      // 测试多任务组的依赖关系
      { from: 51, to: 52, color: '#4ecdc4' }, // Task A -> Task B
      { from: 52, to: 53, color: '#45b7d1' }, // Task B -> Task C
      { from: 53, to: 54, color: '#96ceb4' }, // Task C -> Task D
      { from: 55, to: 51, color: '#ff9ff3' }  // Task E -> Task A
    ],
    viewMode: 'month', // 'year', 'month', 'day'
    currentDate: moment().format('YYYY-MM-DD'),

    // 任务选择状态
    selectedTasks: [],
    selectAllState: false, // false: 未选, true: 全选, 'indeterminate': 部分选中

    // 任务折叠状态
    collapsedTasks: [],

    // 连接线文字信息
    dependencyLabels: {
      '11_21': 'Start Design Phase',
      '21_22': 'Begin Development',
      '22_31': 'Ready for Testing',
      '32_33': 'Integration Complete'
    },

    // 左侧面板控制
    leftPanelVisible: true,

    // 连接线灰色模式控制
    grayConnectionMode: false,

    // 依赖关系高亮 - 增强版本
    highlightedConnections: {
      sourceTaskId: null,
      relatedTaskIds: [],
      relatedDependencies: [], // 相关的依赖关系
      isHighlightMode: false,   // 是否处于高亮模式
      upstreamTasks: [],        // 上游任务
      downstreamTasks: []       // 下游任务
    },

    // 今天日期标记
    todayMarker: {
      enabled: true,
      date: moment().format('YYYY-MM-DD')
    },

    // 列配置
    columnConfig: [
      { id: 'checkbox', prop: 'checkbox', label: 'Select', visible: true, width: 50, order: 0, align: 'center' },
      { id: 'taskName', prop: 'name', label: 'Task Name', visible: true, width: 200, order: 1, align: 'left' },
      { id: 'progress', prop: 'progress', label: 'Progress', visible: true, width: 120, order: 2, align: 'center' },
      { id: 'startDate', prop: 'startDate', label: 'Start Date', visible: true, width: 120, order: 3, align: 'center' },
      { id: 'endDate', prop: 'endDate', label: 'End Date', visible: true, width: 120, order: 4, align: 'center' },
      { id: 'planStartDate', prop: 'planStartDate', label: 'Plan Start', visible: true, width: 120, order: 5, align: 'center' },
      { id: 'planEndDate', prop: 'planEndDate', label: 'Plan End', visible: true, width: 120, order: 6, align: 'center' },
      { id: 'status', prop: 'status', label: 'Status', visible: true, width: 100, order: 7, align: 'center' }
    ]
  },
  mutations: {
    SET_VIEW_MODE(state, mode) {
      state.viewMode = mode
    },
    SET_GANTT_DATA(state, data) {
      state.ganttData = data || []
    },
    UPDATE_GANTT_ITEM(state, payload) {
      const { id, updates, isParentNode, daysDelta } = payload

      const updateTask = (tasks) => {
        for (const task of tasks) {
          if (task.id === id) {
            Object.assign(task, updates)

            // 如果是父级节点拖拽，同步移动所有子节点
            if (isParentNode && daysDelta !== undefined && task.children) {
              console.log(`父节点 ${task.name} 移动 ${daysDelta} 天，开始同步子节点`)

              const moveChildren = (children, depth = 1) => {
                children.forEach(child => {
                  const childStartDate = moment(child.startDate).add(daysDelta, 'days')
                  const childEndDate = moment(child.endDate).add(daysDelta, 'days')

                  console.log(`  ${'  '.repeat(depth)}移动子节点: ${child.name}`)
                  console.log(`  ${'  '.repeat(depth)}原日期: ${child.startDate} - ${child.endDate}`)
                  console.log(`  ${'  '.repeat(depth)}新日期: ${childStartDate.format('YYYY-MM-DD')} - ${childEndDate.format('YYYY-MM-DD')}`)

                  // 更新子节点日期
                  child.startDate = childStartDate.format('YYYY-MM-DD')
                  child.endDate = childEndDate.format('YYYY-MM-DD')

                  // 如果有计划日期，也要同步移动
                  if (child.planStartDate) {
                    child.planStartDate = moment(child.planStartDate).add(daysDelta, 'days').format('YYYY-MM-DD')
                  }
                  if (child.planEndDate) {
                    child.planEndDate = moment(child.planEndDate).add(daysDelta, 'days').format('YYYY-MM-DD')
                  }

                  // 递归处理子节点的子节点
                  if (child.children && child.children.length > 0) {
                    moveChildren(child.children, depth + 1)
                  }
                })
              }

              moveChildren(task.children)
              console.log(`父节点 ${task.name} 及其所有子节点移动完成`)
            }

            return true
          }
          if (task.children && updateTask(task.children)) {
            return true
          }
        }
        return false
      }
      updateTask(state.ganttData)
    },
    ADD_DEPENDENCY(state, dependency) {
      const exists = state.dependencies.find(dep =>
        dep.from === dependency.from && dep.to === dependency.to
      )
      if (!exists) {
        // 如果没有指定颜色，使用默认颜色
        const newDependency = {
          ...dependency,
          color: dependency.color || '#666'
        }
        state.dependencies.push(newDependency)
      }
    },
    REMOVE_DEPENDENCY(state, { from, to }) {
      const index = state.dependencies.findIndex(dep =>
        dep.from === from && dep.to === to
      )
      if (index > -1) {
        state.dependencies.splice(index, 1)
      }

      const labelKey = `${from}_${to}`
      Vue.delete(state.dependencyLabels, labelKey)
    },
    // 任务选择相关
    TOGGLE_TASK_SELECTION(state, taskId) {
      // 防止undefined错误：确保selectedTasks数组存在
      if (!Array.isArray(state.selectedTasks)) {
        console.warn('TOGGLE_TASK_SELECTION: selectedTasks不是数组，重新初始化')
        state.selectedTasks = []
      }

      const index = state.selectedTasks.indexOf(taskId)
      if (index > -1) {
        state.selectedTasks.splice(index, 1)
      } else {
        state.selectedTasks.push(taskId)
      }
    },
    SET_TASK_SELECTION(state, { taskId, selected }) {
      // 防止undefined错误：确保selectedTasks数组存在
      if (!Array.isArray(state.selectedTasks)) {
        console.warn('SET_TASK_SELECTION: selectedTasks不是数组，重新初始化')
        state.selectedTasks = []
      }

      const index = state.selectedTasks.indexOf(taskId)
      if (selected && index === -1) {
        state.selectedTasks.push(taskId)
      } else if (!selected && index > -1) {
        state.selectedTasks.splice(index, 1)
      }
    },
    SELECT_ALL_TASKS(state, allTaskIds) {
      state.selectedTasks = [...allTaskIds]
      state.selectAllState = true
    },
    DESELECT_ALL_TASKS(state) {
      state.selectedTasks = []
      state.selectAllState = false
    },
    UPDATE_SELECT_ALL_STATE(state, allTaskIds) {
      const selectedCount = state.selectedTasks.length
      const totalCount = allTaskIds.length

      if (selectedCount === 0) {
        state.selectAllState = false
      } else if (selectedCount === totalCount) {
        state.selectAllState = true
      } else {
        state.selectAllState = 'indeterminate'
      }
    },
    // 任务折叠相关
    TOGGLE_TASK_COLLAPSED(state, taskId) {
      // 防止undefined错误：确保collapsedTasks数组存在
      if (!Array.isArray(state.collapsedTasks)) {
        console.warn('TOGGLE_TASK_COLLAPSED: collapsedTasks不是数组，重新初始化')
        state.collapsedTasks = []
      }

      const index = state.collapsedTasks.indexOf(taskId)
      if (index > -1) {
        state.collapsedTasks.splice(index, 1)
      } else {
        state.collapsedTasks.push(taskId)
      }
    },
    // 连接线相关
    UPDATE_DEPENDENCY_LABEL(state, { from, to, label }) {
      const key = `${from}_${to}`
      Vue.set(state.dependencyLabels, key, label)
    },
    UPDATE_DEPENDENCY_COLOR(state, { from, to, color }) {
      const dependency = state.dependencies.find(dep =>
        dep.from === from && dep.to === to
      )
      if (dependency) {
        Vue.set(dependency, 'color', color)
      }
    },
    // 任务管理
    ADD_NEW_TASK(state, { task, parentId }) {
      if (parentId) {
        // 添加到指定父任务下
        const addToParent = (tasks) => {
          for (const parent of tasks) {
            if (parent.id === parentId) {
              if (!parent.children) {
                Vue.set(parent, 'children', [])
              }
              parent.children.push(task)
              return true
            }
            if (parent.children && addToParent(parent.children)) {
              return true
            }
          }
          return false
        }
        addToParent(state.ganttData)
      } else {
        // 添加到根级别
        state.ganttData.push({
          id: task.id,
          name: task.name,
          children: [task]
        })
      }
    },
    DELETE_TASK(state, taskId) {
      const deleteFromTasks = (tasks) => {
        for (let i = 0; i < tasks.length; i++) {
          const group = tasks[i]
          if (group.children) {
            for (let j = 0; j < group.children.length; j++) {
              if (group.children[j].id === taskId) {
                group.children.splice(j, 1)
                // 如果分组没有子任务了，删除整个分组
                if (group.children.length === 0) {
                  tasks.splice(i, 1)
                }
                return true
              }
            }
            if (deleteFromTasks(group.children)) {
              return true
            }
          }
        }
        return false
      }

      deleteFromTasks(state.ganttData)

      // 删除相关的依赖关系
      state.dependencies = state.dependencies.filter(dep =>
        dep.from !== taskId && dep.to !== taskId
      )

      // 删除相关的标签
      const labelsToDelete = Object.keys(state.dependencyLabels).filter(key =>
        key.includes(`${taskId}_`) || key.includes(`_${taskId}`)
      )
      labelsToDelete.forEach(key => {
        Vue.delete(state.dependencyLabels, key)
      })

      // 从选中列表中移除
      // 防止undefined错误：确保selectedTasks数组存在
      if (!Array.isArray(state.selectedTasks)) {
        console.warn('DELETE_TASK: selectedTasks不是数组，重新初始化')
        state.selectedTasks = []
      }

      const selectedIndex = state.selectedTasks.indexOf(taskId)
      if (selectedIndex > -1) {
        state.selectedTasks.splice(selectedIndex, 1)
      }
    },

    // 左侧面板控制
    TOGGLE_LEFT_PANEL(state) {
      state.leftPanelVisible = !state.leftPanelVisible
    },

    SET_LEFT_PANEL_VISIBLE(state, visible) {
      state.leftPanelVisible = visible
    },

    // 列配置管理
    UPDATE_COLUMN_CONFIG(state, newConfig) {
      state.columnConfig = newConfig
    },

    UPDATE_COLUMN_VISIBILITY(state, { id, visible }) {
      const column = state.columnConfig.find(col => col.id === id)
      if (column) {
        column.visible = visible
      }
    },

    UPDATE_COLUMN_ORDER(state, { oldIndex, newIndex }) {
      const column = state.columnConfig.splice(oldIndex, 1)[0]
      state.columnConfig.splice(newIndex, 0, column)

      // 重新设置order
      state.columnConfig.forEach((col, index) => {
        col.order = index
      })
    },

    UPDATE_COLUMN_WIDTH(state, { id, width }) {
      const column = state.columnConfig.find(col => col.id === id)
      if (column) {
        column.width = width
      }
    },

    // 设置血缘关系高亮 - 增强版本
    SET_LINEAGE_HIGHLIGHT(state, { sourceTaskId }) {
      if (!sourceTaskId) {
        state.highlightedConnections = {
          sourceTaskId: null,
          relatedTaskIds: [],
          relatedDependencies: [],
          isHighlightMode: false,
          upstreamTasks: [],
          downstreamTasks: []
        }
        return
      }

      // 找到所有上游任务（递归）
      const findUpstreamTasks = (taskId, visited = new Set()) => {
        if (visited.has(taskId)) return []
        visited.add(taskId)

        const upstream = []
        state.dependencies.forEach(dep => {
          if (dep.to === taskId) {
            upstream.push(dep.from)
            upstream.push(...findUpstreamTasks(dep.from, visited))
          }
        })
        return [...new Set(upstream)]
      }

      // 找到所有下游任务（递归）
      const findDownstreamTasks = (taskId, visited = new Set()) => {
        if (visited.has(taskId)) return []
        visited.add(taskId)

        const downstream = []
        state.dependencies.forEach(dep => {
          if (dep.from === taskId) {
            downstream.push(dep.to)
            downstream.push(...findDownstreamTasks(dep.to, visited))
          }
        })
        return [...new Set(downstream)]
      }

      const upstreamTasks = findUpstreamTasks(sourceTaskId)
      const downstreamTasks = findDownstreamTasks(sourceTaskId)
      const allRelatedTasks = [sourceTaskId, ...upstreamTasks, ...downstreamTasks]

      // 找到所有相关的依赖关系
      const relatedDependencies = state.dependencies.filter(dep =>
        allRelatedTasks.includes(dep.from) && allRelatedTasks.includes(dep.to)
      )

      state.highlightedConnections = {
        sourceTaskId,
        relatedTaskIds: allRelatedTasks,
        relatedDependencies,
        isHighlightMode: true,
        upstreamTasks,
        downstreamTasks
      }
    },

    // 清除血缘关系高亮
    CLEAR_LINEAGE_HIGHLIGHT(state) {
      state.highlightedConnections = {
        sourceTaskId: null,
        relatedTaskIds: [],
        relatedDependencies: [],
        isHighlightMode: false,
        upstreamTasks: [],
        downstreamTasks: []
      }
    },

    // 今天标记相关
    SET_TODAY_MARKER(state, enabled) {
      state.todayMarker.enabled = enabled
      state.todayMarker.date = moment().format('YYYY-MM-DD')
    },

    JUMP_TO_TODAY(state) {
      state.currentDate = moment().format('YYYY-MM-DD')
      state.todayMarker.date = moment().format('YYYY-MM-DD')
    },

    UPDATE_CURRENT_DATE(state, date) {
      state.currentDate = date
    },

    // 设置连接高亮
    SET_CONNECTION_HIGHLIGHT(state, { sourceTaskId, relatedTaskIds }) {
      state.highlightedConnections = {
        sourceTaskId,
        relatedTaskIds
      }
    },

    // 清除连接高亮
    CLEAR_CONNECTION_HIGHLIGHT(state) {
      state.highlightedConnections = {
        sourceTaskId: null,
        relatedTaskIds: []
      }
    },

    ADD_TASK_WITH_PARENT(state, { task, parentTask, newParentTask, insertPosition }) {
      if (newParentTask) {
        // 创建新的父级任务组
        newParentTask.children = [task]
        state.ganttData.push(newParentTask)
      } else if (parentTask) {
        // 添加到现有父级任务
        if (!parentTask.children) {
          Vue.set(parentTask, 'children', [])
        }

        // 如果有指定插入位置，则插入到指定位置，否则追加到末尾
        if (insertPosition && insertPosition.insertIndex !== undefined) {
          parentTask.children.splice(insertPosition.insertIndex, 0, task)
        } else {
          parentTask.children.push(task)
        }
      } else if (insertPosition && insertPosition.parentGroup) {
        // 同级任务插入到指定组的指定位置
        if (!insertPosition.parentGroup.children) {
          Vue.set(insertPosition.parentGroup, 'children', [])
        }
        insertPosition.parentGroup.children.splice(insertPosition.insertIndex, 0, task)
      } else {
        // 添加为独立的根级任务组
        const rootTask = {
          id: Date.now() + Math.floor(Math.random() * 10000),
          name: `${task.name  } Group`,
          children: [task],
          level: 0,
          color: task.color,
          isParentNode: true
        }
        state.ganttData.push(rootTask)
      }
    },

    SET_COLLAPSED_TASKS(state, tasks) {
      state.collapsedTasks = Array.isArray(tasks) ? tasks : []
    },

    // 设置连接线灰色模式
    SET_GRAY_CONNECTION_MODE(state, grayMode) {
      state.grayConnectionMode = grayMode
    }
  },
  actions: {
    setViewMode({ commit }, mode) {
      commit('SET_VIEW_MODE', mode)
    },
    updateGanttItem({ commit }, payload) {
      commit('UPDATE_GANTT_ITEM', payload)
    },
    addDependency({ commit }, dependency) {
      commit('ADD_DEPENDENCY', dependency)
    },
    // 任务选择相关
    toggleTaskSelection({ commit, getters }, taskId) {
      commit('TOGGLE_TASK_SELECTION', taskId)
      commit('UPDATE_SELECT_ALL_STATE', getters.allTaskIds)
    },
    setTaskSelection({ commit, getters }, payload) {
      commit('SET_TASK_SELECTION', payload)
      commit('UPDATE_SELECT_ALL_STATE', getters.allTaskIds)
    },
    toggleSelectAll({ commit, state, getters }) {
      if (state.selectAllState === true) {
        commit('DESELECT_ALL_TASKS')
      } else {
        commit('SELECT_ALL_TASKS', getters.allTaskIds)
      }
    },
    // 任务折叠相关
    toggleTaskCollapsed({ commit }, taskId) {
      commit('TOGGLE_TASK_COLLAPSED', taskId)
    },
    // 连接线相关
    updateDependencyLabel({ commit }, payload) {
      commit('UPDATE_DEPENDENCY_LABEL', payload)
      if (payload.color) {
        commit('UPDATE_DEPENDENCY_COLOR', payload)
      }
    },
    removeDependency({ commit }, payload) {
      commit('REMOVE_DEPENDENCY', payload)
    },
    // 任务管理
    addNewTask({ commit }, payload) {
      commit('ADD_NEW_TASK', payload)
    },
    addTask({ commit }, task) {
      commit('ADD_NEW_TASK', { task, parentId: null })
    },
    addTaskWithParent({ commit }, { task, parentTask, newParentTask }) {
      commit('ADD_TASK_WITH_PARENT', { task, parentTask, newParentTask })
    },
    deleteTask({ commit }, taskId) {
      commit('DELETE_TASK', taskId)
    },

    // 移动任务到新的父任务
    moveTaskToNewParent({ commit, state }, { taskId, newParentId, updates }) {
      // 先删除任务从原位置
      commit('DELETE_TASK', taskId)

      // 创建新的任务对象
      const newTask = {
        ...updates,
        id: taskId,
        parentId: newParentId
      }

      // 添加到新位置
      if (newParentId) {
        commit('ADD_NEW_TASK', { task: newTask, parentId: newParentId })
      } else {
        // 如果新父任务为null，作为根级任务添加
        commit('ADD_NEW_TASK', { task: newTask, parentId: null })
      }
    },
    // 左侧面板控制
    toggleLeftPanel({ commit }) {
      commit('TOGGLE_LEFT_PANEL')
    },
    setLeftPanelVisible({ commit }, visible) {
      commit('SET_LEFT_PANEL_VISIBLE', visible)
    },
    // 列配置管理
    updateColumnConfig({ commit }, newConfig) {
      commit('UPDATE_COLUMN_CONFIG', newConfig)
    },
    updateColumnVisibility({ commit }, payload) {
      commit('UPDATE_COLUMN_VISIBILITY', payload)
    },
    updateColumnOrder({ commit }, payload) {
      commit('UPDATE_COLUMN_ORDER', payload)
    },
    updateColumnWidth({ commit }, payload) {
      commit('UPDATE_COLUMN_WIDTH', payload)
    },
    // 血缘关系高亮相关
    setLineageHighlight({ commit }, sourceTaskId) {
      commit('SET_LINEAGE_HIGHLIGHT', { sourceTaskId })
    },

    clearLineageHighlight({ commit }) {
      commit('CLEAR_LINEAGE_HIGHLIGHT')
    },

    toggleLineageHighlight({ commit, state }, sourceTaskId) {
      if (state.highlightedConnections.sourceTaskId === sourceTaskId) {
        commit('CLEAR_LINEAGE_HIGHLIGHT')
      } else {
        commit('SET_LINEAGE_HIGHLIGHT', { sourceTaskId })
      }
    },

    // 今天标记相关
    jumpToToday({ commit }) {
      commit('JUMP_TO_TODAY')
    },

    setTodayMarker({ commit }, enabled) {
      commit('SET_TODAY_MARKER', enabled)
    },

    updateCurrentDate({ commit }, date) {
      commit('UPDATE_CURRENT_DATE', date)
    },

    // 生成大量测试数据用于演示虚拟滚动
    generateLargeDataset({ commit }, count = 1000) {
      const priorities = ['low', 'medium', 'high', 'critical']
      const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#34495e', '#e67e22']
      const departments = ['Development', 'Design', 'Marketing', 'Sales', 'HR', 'Finance', 'Operations']
      const taskTypes = ['Feature', 'Bug Fix', 'Enhancement', 'Research', 'Documentation', 'Testing', 'Review']
      const assignees = ['Alice Johnson', 'Bob Smith', 'Carol Davis', 'David Wilson', 'Eve Brown', 'Frank Miller', 'Grace Lee', 'Henry Taylor']
      const subTaskTypes = ['Analysis', 'Design', 'Implementation', 'Testing', 'Review', 'Deployment']

      const generateRandomDate = (start, end) => {
        return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
      }

      const baseStartDate = new Date('2024-01-01')
      const baseEndDate = new Date('2024-12-31')

      const ganttData = []

      // 生成父级任务组
      const parentGroups = Math.ceil(count / 100) // 每100个任务一个父级组，支持三级结构

      for (let g = 0; g < parentGroups; g++) {
        const parentId = `parent_${g + 1}`
        const parentStartDate = generateRandomDate(baseStartDate, new Date('2024-06-01'))
        const parentEndDate = generateRandomDate(new Date(parentStartDate.getTime() + 60 * 24 * 60 * 60 * 1000), baseEndDate)

        // 创建父级任务（第一级）
        const parentTask = {
          id: parentId,
          name: `${departments[g % departments.length]} - ${taskTypes[g % taskTypes.length]} Phase ${g + 1}`,
          startDate: parentStartDate.toISOString().split('T')[0],
          endDate: parentEndDate.toISOString().split('T')[0],
          progress: Math.floor(Math.random() * 101),
          priority: priorities[Math.floor(Math.random() * priorities.length)],
          color: colors[g % colors.length],
          assignee: assignees[g % assignees.length],
          description: `Parent task for ${departments[g % departments.length]} department`,
          level: 0,
          children: [],
          isParentNode: true,
          department: departments[g % departments.length],
          estimatedHours: Math.floor(Math.random() * 400) + 100,
          actualHours: Math.floor(Math.random() * 360) + 80
        }

        // 为每个父级任务生成子任务（第二级）
        const childGroupCount = Math.min(5, Math.ceil((count - g * 100) / 20)) // 每个父级最多5个子任务组
        for (let c = 0; c < childGroupCount; c++) {
          const childId = `${parentId}_child_${c + 1}`
          const childStartDate = generateRandomDate(parentStartDate, new Date(parentEndDate.getTime() - 20 * 24 * 60 * 60 * 1000))
          const childEndDate = generateRandomDate(new Date(childStartDate.getTime() + 10 * 24 * 60 * 60 * 1000), parentEndDate)

          const childTask = {
            id: childId,
            name: `${taskTypes[c % taskTypes.length]} Module ${c + 1}`,
            startDate: childStartDate.toISOString().split('T')[0],
            endDate: childEndDate.toISOString().split('T')[0],
            planStartDate: new Date(childStartDate.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            planEndDate: new Date(childEndDate.getTime() + 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            progress: Math.floor(Math.random() * 101),
            priority: priorities[Math.floor(Math.random() * priorities.length)],
            color: colors[Math.floor(Math.random() * colors.length)],
            assignee: assignees[Math.floor(Math.random() * assignees.length)],
            description: `Second level task for ${taskTypes[c % taskTypes.length]}`,
            level: 1,
            parentId,
            children: [],
            isParentNode: true,
            department: departments[g % departments.length],
            taskType: taskTypes[c % taskTypes.length],
            estimatedHours: Math.floor(Math.random() * 80) + 20,
            actualHours: Math.floor(Math.random() * 70) + 15
          }

          // 为每个子任务生成孙任务（第三级）
          const grandChildCount = Math.min(6, Math.ceil((count - g * 100 - c * 20) / 4)) // 每个子任务最多6个孙任务
          for (let gc = 0; gc < grandChildCount; gc++) {
            const grandChildIndex = g * 100 + c * 20 + gc
            if (grandChildIndex >= count) break

            const grandChildStartDate = generateRandomDate(childStartDate, new Date(childEndDate.getTime() - 3 * 24 * 60 * 60 * 1000))
            const grandChildEndDate = generateRandomDate(new Date(grandChildStartDate.getTime() + 3 * 24 * 60 * 60 * 1000), childEndDate)

            const grandChildTask = {
              id: `task_${grandChildIndex + 1}`,
              name: `${subTaskTypes[gc % subTaskTypes.length]} #${grandChildIndex + 1}: ${taskTypes[c % taskTypes.length]} Detail`,
              startDate: grandChildStartDate.toISOString().split('T')[0],
              endDate: grandChildEndDate.toISOString().split('T')[0],
              planStartDate: new Date(grandChildStartDate.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              planEndDate: new Date(grandChildEndDate.getTime() + 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              progress: Math.floor(Math.random() * 101),
              priority: priorities[Math.floor(Math.random() * priorities.length)],
              color: colors[Math.floor(Math.random() * colors.length)],
              assignee: assignees[Math.floor(Math.random() * assignees.length)],
              description: `Third level task for ${subTaskTypes[gc % subTaskTypes.length]} in ${taskTypes[c % taskTypes.length]}`,
              level: 2,
              parentId: childId,
              children: [],
              department: departments[g % departments.length],
              taskType: `${taskTypes[c % taskTypes.length]} - ${subTaskTypes[gc % subTaskTypes.length]}`,
              estimatedHours: Math.floor(Math.random() * 16) + 2,
              actualHours: Math.floor(Math.random() * 14) + 1,
              tags: [`${departments[g % departments.length].toLowerCase()}`, `${subTaskTypes[gc % subTaskTypes.length].toLowerCase()}`],
              // 随机添加一些milestone标记
              milestone: Math.random() < 0.1 // 10%的概率是milestone
            }

            childTask.children.push(grandChildTask)
          }

          parentTask.children.push(childTask)
        }

        ganttData.push(parentTask)
      }

      // 更新状态
      commit('SET_GANTT_DATA', ganttData)

      // 计算实际任务数量
      const countTotalTasks = (tasks) => {
        let total = 0
        tasks.forEach(task => {
          total += 1
          if (task.children && task.children.length > 0) {
            total += countTotalTasks(task.children)
          }
        })
        return total
      }

      const totalGeneratedTasks = countTotalTasks(ganttData)

      return {
        totalTasks: totalGeneratedTasks,
        parentGroups: ganttData.length,
        childGroups: ganttData.reduce((total, parent) => total + parent.children.length, 0),
        leafTasks: ganttData.reduce((total, parent) => {
          return total + parent.children.reduce((childTotal, child) => childTotal + child.children.length, 0)
        }, 0)
      }
    },
    // 切换连接线灰色模式
    toggleGrayConnectionMode({ commit, state }) {
      commit('SET_GRAY_CONNECTION_MODE', !state.grayConnectionMode)
    }
  },
  getters: {
    allTaskIds: (state) => {
      const ids = []
      const collectIds = (tasks) => {
        tasks.forEach(task => {
          ids.push(task.id)
          if (task.children) {
            collectIds(task.children)
          }
        })
      }
      collectIds(state.ganttData)
      return ids
    },
    isTaskSelected: (state) => (taskId) => {
      return state.selectedTasks.includes(taskId)
    },
    isTaskCollapsed: (state) => (taskId) => {
      return state.collapsedTasks.includes(taskId)
    },
    visibleTasks: (state, getters) => {
      const visible = []
      const traverse = (tasks, level = 0) => {
        tasks.forEach(task => {
          const hasChildren = task.children && task.children.length > 0

          // 为父级节点计算日期范围和进度
          const taskData = { ...task, level, isParentNode: hasChildren }

          if (hasChildren) {
            // 计算父级节点的开始和结束日期
            let minStart = null
            let maxEnd = null
            let totalProgress = 0
            let taskCount = 0

            const calculateFromChildren = (children) => {
              children.forEach(child => {
                if (child.startDate) {
                  const startDate = new Date(child.startDate)
                  if (!minStart || startDate < minStart) {
                    minStart = startDate
                  }
                }

                if (child.endDate) {
                  const endDate = new Date(child.endDate)
                  if (!maxEnd || endDate > maxEnd) {
                    maxEnd = endDate
                  }
                }

                if (typeof child.progress === 'number') {
                  totalProgress += child.progress
                  taskCount++
                }

                // 递归处理子任务的子任务
                if (child.children && child.children.length > 0) {
                  calculateFromChildren(child.children)
                }
              })
            }

            calculateFromChildren(task.children)

            // 设置父级节点的日期和进度
            if (minStart) {
              taskData.startDate = minStart.toISOString().split('T')[0]
            }
            if (maxEnd) {
              taskData.endDate = maxEnd.toISOString().split('T')[0]
            }
            if (taskCount > 0) {
              taskData.progress = Math.round(totalProgress / taskCount)
            }

            // 确保父级节点有颜色
            if (!taskData.color) {
              taskData.color = '#667eea'
            }
          }

          visible.push(taskData)

          if (hasChildren && !getters.isTaskCollapsed(task.id)) {
            traverse(task.children, level + 1)
          }
        })
      }
      traverse(state.ganttData)
      return visible
    },
    getDependencyLabel: (state) => (from, to) => {
      const key = `${from}_${to}`
      return state.dependencyLabels[key] || ''
    },
    // 列配置相关
    visibleColumns: (state) => {
      return state.columnConfig
        .filter(col => col.visible)
        .sort((a, b) => a.order - b.order)
    },
    getColumnConfig: (state) => {
      return state.columnConfig.slice().sort((a, b) => a.order - b.order)
    },
    isLeftPanelVisible: (state) => {
      return state.leftPanelVisible
    },
    // 血缘关系相关getter
    isTaskHighlighted: (state) => (taskId) => {
      if (!state.highlightedConnections.isHighlightMode) return false
      return state.highlightedConnections.relatedTaskIds.includes(taskId)
    },

    isTaskDimmed: (state) => (taskId) => {
      if (!state.highlightedConnections.isHighlightMode) return false
      return !state.highlightedConnections.relatedTaskIds.includes(taskId)
    },

    getTaskHighlightType: (state) => (taskId) => {
      if (!state.highlightedConnections.isHighlightMode) return 'normal'

      if (state.highlightedConnections.sourceTaskId === taskId) return 'source'
      if (state.highlightedConnections.upstreamTasks.includes(taskId)) return 'upstream'
      if (state.highlightedConnections.downstreamTasks.includes(taskId)) return 'downstream'

      return state.highlightedConnections.relatedTaskIds.includes(taskId) ? 'related' : 'dimmed'
    },

    isDependencyHighlighted: (state) => (dependency) => {
      if (!state.highlightedConnections.isHighlightMode) return false
      return state.highlightedConnections.relatedDependencies.some(dep =>
        dep.from === dependency.from && dep.to === dependency.to
      )
    },

    // 今天相关getter
    getTodayDate: (state) => {
      return state.todayMarker.date
    },

    isTodayMarkerEnabled: (state) => {
      return state.todayMarker.enabled
    },

    isToday: (state) => (date) => {
      return date === state.todayMarker.date
    }
  }
})
