<template>
  <div class="gantt-chart gantt-performance-mode gpu-accelerated">
    <!-- 概览时间轴 -->
    <GanttOverviewTimeline
      v-if="timelineVisible"
      ref="ganttOverviewTimeline"
      :tasks="flattenTasks"
      :start-date="chartStartDate"
      :end-date="chartEndDate"
      :visible="timelineVisible"
      @milestone-selected="handleMilestoneSelected"
      @timeline-hidden="handleTimelineHidden"
    />

    <!-- 控制面板已移除，设置按钮已移至Performance Monitor -->

    <!-- 甘特图主体 -->
    <div class="gantt-main render-optimized" ref="ganttMain" :style="{height: '100%'}">
      <!-- 左侧任务列表 -->
      <div
        class="gantt-left gantt-grid-optimized"
        :style="{ width: leftPanelVisible ? leftWidth + 'px' : '0px', height: '100%' }"
        v-show="leftPanelVisible"
      >
        <!-- 使用虚拟滚动表格或普通表格 -->
        <BetterVirtualScrollTable
          v-if="shouldUseVirtualScrolling"
          :data="flatTableDataForVirtual"
          :columns="tableColumns"
          :item-height="virtualScrollConfig.itemHeight"
          :container-height="tableHeight"
          :highlighted-row-id="highlightedRowId"
          :buffer-size="virtualScrollConfig.bufferSize"
          @row-click="handleRowClick"
          @sort="handleVirtualTableSort"
          @scroll="handleVirtualTableScroll"
          ref="virtualTable"
        >
          <!-- 自定义插槽 -->
          <template #name="{ item, value }">
            <div class="task-name-cell">
              <span
                v-if="item.children && item.children.length > 0"
                class="collapse-btn"
                @click.stop="handleToggleCollapse(item.id)"
              >
                {{ item.collapsed ? '▶' : '▼' }}
              </span>
              <span class="task-name" :title="value">{{ value }}</span>
            </div>
          </template>

          <template #progress="{ value }">
            <div class="progress-cell">
              <div class="progress-bar">
                <div
                  class="progress-fill"
                  :style="{ width: value + '%' }"
                ></div>
              </div>
              <span class="progress-text">{{ value }}%</span>
            </div>
          </template>

          <template #status="{ item }">
            <span
              class="status-badge"
              :class="getStatusClass(item)"
            >
              {{ getTaskStatus(item) }}
            </span>
          </template>
        </BetterVirtualScrollTable>

        <!-- 普通表格 -->
        <CustomGanttTable
          v-else
          :tasks="flatTableData"
          :highlighted-row-id="highlightedRowId"
          :table-height="tableHeight"
          @row-click="handleRowClick"
          @toggle-collapse="handleToggleCollapse"
          @scroll="handleTableScroll"
          @show-column-config="showColumnConfigDialog"
          @edit-task="editTask"
          @delete-task="deleteTask"
          @add-sibling-task="addSiblingTask"
          @add-child-task="addChildTask"
          @table-mounted="handleTableMounted"
          @column-reorder="handleColumnReorder"
          ref="customTable"
        />

        <!-- Performance Monitor 在左侧面板底部 -->
        <PerformanceMonitor
          :enabled="performanceMonitorEnabled"
          :task-count="flattenTasks.length"
          :visible-task-count="visibleTaskCount"
          :render-time="currentRenderTime"
          @auto-optimize-toggle="handleAutoOptimizeToggle"
          @open-settings="openSettingsDialog"
          class="left-panel-performance-monitor"
        />
      </div>

      <!-- 拖拽分隔线 -->
      <div
        class="gantt-splitter"
        @mousedown="startResize"
        ref="splitter"
        v-show="leftPanelVisible"
      >
        <!-- 隐藏左侧面板按钮 -->
        <button
          class="toggle-panel-btn hide-btn"
          @click="toggleLeftPanel"
          title="Hide Left Panel"
        >
          <i class="el-icon-arrow-left"></i>
        </button>
      </div>

      <!-- 显示左侧面板按钮（当左侧隐藏时显示） -->
      <div
        class="show-panel-btn"
        v-show="!leftPanelVisible"
        @click="toggleLeftPanel"
        title="Show Left Panel"
      >
        <i class="el-icon-arrow-right"></i>
      </div>

      <!-- 右侧图表区域 -->
      <div class="gantt-right" ref="ganttRight" :style="{height: '100%'}">
        <!-- 工具栏 -->
        <!-- <div class="gantt-toolbar">
          <el-button
            size="small"
            :type="ganttDisplayConfig.showCriticalPath ? 'primary' : 'default'"
            @click="toggleCriticalPath"
            icon="el-icon-connection"
            class="critical-path-btn"
          >
            {{ ganttDisplayConfig.showCriticalPath ? '隐藏关键路径' : '显示关键路径' }}
          </el-button>
        </div> -->

        <!-- 整个右侧滚动容器 -->
                  <div
            class="gantt-scroll-container"
            :class="{ 'dragging': isDragging }"
            ref="scrollContainer"
            @scroll="handleRightScroll"
            @mousedown="handleDragStart"
            @mousemove="handleDragMove"
            @mouseup="handleDragEnd"
            @mouseleave="handleDragEnd"
            :style="{height: '100%', overflowX: 'visible', overflowY: 'auto', width: '100%'}"
          >
          <!-- 时间轴头部 - 跟着内容一起滚动 -->
          <div class="gantt-timeline-wrapper">
            <GanttTimeline
              :key="timelineRefreshKey"
              :view-mode="effectiveViewMode"
              :start-date="chartStartDate"
              :end-date="chartEndDate"
              :zoom-level="zoomLevel"
              :pan-offset="panOffset"
              :container-width="rightAreaWidth"
              ref="timeline"
            />
          </div>

          <!-- 甘特图内容区域 -->
          <div
            class="gantt-chart-area"
            ref="chartArea"
            @mousedown="noop"
            @wheel.prevent="noop"
            @click="handleChartAreaClick"
            tabindex="0"
            :style="{
              cursor: isPanning ? 'grabbing' : 'grab',
              minHeight: actualGanttHeight + 'px',
              height: 'auto'
            }"
          >
            <div
              class="gantt-content"
              :style="{
                transform: `translateX(${panOffset}px)`,
                transformOrigin: '0 0',
                minHeight: actualGanttHeight + 'px',
                height: actualGanttHeight + 'px',
                width: rightAreaWidth + 'px'
              }"
            >
              <GanttChartGrid
                :key="'grid-' + timelineRefreshKey"
                :view-mode="effectiveViewMode"
                :start-date="chartStartDate"
                :end-date="chartEndDate"
                :tasks="flattenTasks"
                :zoom-level="zoomLevel"
                :container-width="rightAreaWidth"
              />
              <GanttBars
                :key="'bars-' + timelineRefreshKey"
                :tasks="flattenTasks"
                :dependencies="ganttData"
                :view-mode="effectiveViewMode"
                :start-date="chartStartDate"
                :end-date="chartEndDate"
                :zoom-level="zoomLevel"
                :highlighted-row-id="highlightedRowId"
                :close-modal-trigger="closeModalTrigger"
                :container-width="rightAreaWidth"
                :chart-width="rightAreaWidth"
                :chart-height="actualGanttHeight"
                :left-panel-width="leftPanelVisible ? leftWidth : 0"
                :tooltip-enabled="tooltipEnabled"
                :tooltip-delay="tooltipDelay"
                :tooltip-hide-delay="tooltipHideDelay"
                :show-task-name="ganttDisplayConfig.showTaskName"
                :show-progress="ganttDisplayConfig.showProgress"
                :show-progress-handle="ganttDisplayConfig.showProgressHandle"
                :show-connections="ganttDisplayConfig.showConnections"
                :show-connection-labels="ganttDisplayConfig.showConnectionLabels"
                :show-plan-nodes="ganttDisplayConfig.showPlanNodes"
                :show-milestones="ganttDisplayConfig.showMilestones"
                :show-critical-path="ganttDisplayConfig.showCriticalPath"
                :allow-parent-drag="ganttDisplayConfig.allowParentDrag"
                :allow-parent-edit="ganttDisplayConfig.allowParentEdit"
                :highlight-task-lineage="ganttDisplayConfig.highlightTaskLineage"
                :connection-editable="connectionEditable"
                :connection-default-color="connectionDefaultColor"
                @bar-drag="handleBarDrag"
                @bar-resize="handleBarResize"
                @task-update="handleTaskUpdate"
                @task-delete="handleTaskDelete"
                @task-highlight="handleTaskHighlight"
                @request-pan="handleRequestPan"
                @update-chart-width="handleUpdateChartWidth"
              />
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 列配置对话框 -->
    <el-dialog
      title="Column Configuration"
      :visible.sync="showColumnDialog"
      width="500px"
      :close-on-click-modal="false"
      :close-on-press-escape="true"
      :append-to-body="true"
      :modal-append-to-body="true"
    >
      <div class="column-config">
        <el-table
          :data="availableColumns"
          size="small"
          max-height="400"
          ref="columnConfigTable"
          row-key="id"
        >
          <el-table-column label="Visible" width="80">
            <template slot-scope="scope">
              <el-checkbox
                v-model="scope.row.visible"
                @change="updateColumnVisibility(scope.row)"
              />
            </template>
          </el-table-column>
          <el-table-column label="Order" width="60">
            <template slot-scope="">
              <span class="drag-handle-column">
                <i class="el-icon-rank"></i>
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="label" label="Column Name" />
          <el-table-column label="Width" width="120">
            <template slot-scope="scope">
              <el-input-number
                v-model="scope.row.width"
                style="width:100%"
                :min="80"
                :max="300"
                size="mini"
                @change="updateColumnWidth(scope.row)"
              />
            </template>
          </el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showColumnDialog = false">Cancel</el-button>
        <el-button type="primary" @click="saveColumnConfig">Save</el-button>
      </span>
    </el-dialog>

    <!-- 添加任务对话框 -->
    <el-dialog
      :title="dialogTitle"
      :visible.sync="showAddDialog"
      width="700px"
      :close-on-click-modal="false"
      :close-on-press-escape="true"
      :append-to-body="false"
      :modal-append-to-body="false"
      @close="resetTaskForm"
    >
      <el-form
        :model="newTask"
        ref="addTaskForm"
        label-width="140px"
        size="medium"
        :rules="taskFormRules"
      >
        <el-form-item
          label="Task Name"
          prop="name"
        >
          <el-input
            v-model="newTask.name"
            placeholder="Enter task name"
            clearable
          />
        </el-form-item>

        <!-- 父任务显示/选择 -->
        <el-form-item
          v-if="shouldShowParentSelection"
          label="Parent Task"
          prop="parentId"
        >
          <el-select
            v-model="newTask.parentId"
            placeholder="Select parent task (optional)"
            style="width: 100%"
            clearable
            filterable
            :append-to-body="true"
          >
            <el-option label="Create as Root Task" :value="null"></el-option>
            <el-option label="Add New Parent Group" :value="'new_parent'"></el-option>
            <el-option-group
              v-for="group in parentTaskOptions"
              :key="group.label"
              :label="group.label"
            >
              <el-option
                v-for="task in group.options"
                :key="task.value"
                :label="task.label"
                :value="task.value"
              />
            </el-option-group>
          </el-select>
        </el-form-item>

        <!-- 父任务名称只读显示 - Add Sibling Task时自动选中且不可修改 -->
        <el-form-item
          v-if="shouldShowParentDisplay"
          label="Parent Task"
        >
          <el-input
            :value="parentTaskDisplayName"
            readonly
            style="width: 100%"
            placeholder="无父任务"
          >
            <template slot="prepend">
              <i class="el-icon-lock"></i>
            </template>
            <template slot="append">
              <span style="color: #909399; font-size: 12px;">不可修改</span>
            </template>
          </el-input>
        </el-form-item>

        <!-- 新增父级组表单 -->
        <el-form-item
          v-if="newTask.parentId === 'new_parent'"
          label="New Parent Name"
          prop="newParentName"
        >
          <el-input
            v-model="newTask.newParentName"
            placeholder="Enter new parent group name"
            clearable
          />
        </el-form-item>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item
              label="Start Date"
              prop="startDate"
            >
              <el-date-picker
                v-model="newTask.startDate"
                type="date"
                placeholder="Select start date"
                style="width: 100%"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
                :append-to-body="true"
                @change="validateDateRange"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item
              label="End Date"
              prop="endDate"
            >
              <el-date-picker
                v-model="newTask.endDate"
                type="date"
                placeholder="Select end date"
                style="width: 100%"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
                :append-to-body="true"
                :picker-options="endDatePickerOptions"
                @change="validateDateRange"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="Plan Start">
              <el-date-picker
                v-model="newTask.planStartDate"
                type="date"
                placeholder="Select plan start date"
                style="width: 100%"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
                :append-to-body="true"
                @change="validatePlanDateRange"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Plan End">
              <el-date-picker
                v-model="newTask.planEndDate"
                type="date"
                placeholder="Select plan end date"
                style="width: 100%"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
                :append-to-body="true"
                :picker-options="planEndDatePickerOptions"
                @change="validatePlanDateRange"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="Progress">
              <el-slider
                v-model="newTask.progress"
                :min="0"
                :max="100"
                show-input
                :show-input-controls="false"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="Priority">
              <el-select v-model="newTask.priority" placeholder="Select priority" :append-to-body="true">
                <el-option label="Low" value="low"></el-option>
                <el-option label="Medium" value="medium"></el-option>
                <el-option label="High" value="high"></el-option>
                <el-option label="Critical" value="critical"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="Color">
              <el-color-picker
                v-model="newTask.color"
                :predefine="predefineColors"
                :append-to-body="true"
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="Description">
          <el-input
            v-model="newTask.description"
            type="textarea"
            :rows="3"
            placeholder="Enter task description (optional)"
          />
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="addNewTask" :loading="addingTask">
          {{ addingTask ? '处理中...' : dialogButtonText }}
        </el-button>
      </span>
    </el-dialog>



    <!-- 设置对话框 -->
    <SettingsDialog
      :visible="showSettingsDialog"
      @update:visible="handleSettingsVisibleChange"
      :date-range="dateRange"
      :tooltip-enabled="tooltipEnabled"
      :tooltip-delay="tooltipDelay"
      :tooltip-hide-delay="tooltipHideDelay"
      :timeline-visible="timelineVisible"
      :gray-connection-mode="grayConnectionMode"
      :auto-optimize-enabled="autoOptimizeConfig.enabled"
      :highlighted-connections="highlightedConnections"
      :gantt-display-config="ganttDisplayConfig"
      :connection-editable="connectionEditable"
      :connection-default-color="connectionDefaultColor"
      @date-range-change="handleDateRangeChange"
      @auto-range="autoRangeDebounced"
      @tooltip-enabled-change="toggleTooltip"
      @tooltip-delay-change="updateTooltipDelay"
      @tooltip-hide-delay-change="updateTooltipHideDelay"
      @timeline-visible-change="updateTimelineVisible"
      @gray-connection-mode-change="toggleGrayConnectionMode"
      @clear-highlight="clearLineageHighlight"
      @auto-optimize-change="handleAutoOptimizeToggle"
      @gantt-display-config-change="handleGanttDisplayConfigChange"
      @connection-editable-change="handleConnectionEditableChange"
      @jump-to-today="jumpToTodayEnhanced"
      @show-add-task-dialog="showAddTaskDialog"
      @export-data="exportData"
      @generate-test-data="generateTestData"
      @settings-save="handleSettingsSave"
    />
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import moment from 'moment'
import GanttTimeline from './GanttTimeline.vue'
import GanttChartGrid from './GanttChartGrid.vue'
import GanttBars from './GanttBars.vue'
import Sortable from 'sortablejs'
import CustomGanttTable from './CustomGanttTable.vue'
import BetterVirtualScrollTable from './BetterVirtualScrollTable.vue'
import PerformanceMonitor from './PerformanceMonitor.vue'
import GanttOverviewTimeline from './GanttOverviewTimeline.vue'
import SettingsDialog from './SettingsDialog.vue'
import debounce from 'lodash/debounce'

export default {
  name: 'GanttChart',
  components: {
    GanttTimeline,
    GanttChartGrid,
    GanttBars,
    CustomGanttTable,
    BetterVirtualScrollTable,
    PerformanceMonitor,
    GanttOverviewTimeline,
    SettingsDialog
  },
  props: {
    data: {
      type: Array,
      default: () => []
    },
    // Tooltip配置
    tooltipEnabled: {
      type: Boolean,
      default: false
    },
    tooltipDelay: {
      type: Number,
      default: 1000
    },
    tooltipHideDelay: {
      type: Number,
      default: 300
    },
    // Timeline 可见性控制
    timelineVisible: {
      type: Boolean,
      default: true
    },
    // 设置对话框控制（从App.vue传递）
    showSettingsDialog: {
      type: Boolean,
      default: false
    },
    // 当前视图模式（从App.vue传递）
    currentViewMode: {
      type: String,
      default: 'month'
    },
    // 连接线是否可编辑
    connectionEditable: {
      type: Boolean,
      default: true  // 默认启用连接线编辑
    },
    // 连接线默认颜色（当不可编辑时）
    connectionDefaultColor: {
      type: String,
      default: '#9ca3af'
    }
  },
  data() {
    return {

      // 日期范围
      dateRange: [],

      // 缩放和平移
      zoomLevel: 1,
      panOffset: 0,
      isPanning: false,

      // 左侧面板
      leftWidth: 400,

      // 高亮行
      highlightedRowId: null,

      // 模态框控制
      closeModalTrigger: 0,

      // 调整大小相关
      isResizing: false,
      startX: 0,
      startWidth: 0,

      // 列配置对话框
      showColumnDialog: false,

      // 添加任务对话框
      showAddDialog: false,
      addingTask: false,
      dialogMode: 'add', // 'add', 'edit', 'add-sibling', 'add-child'
      editingTaskId: null, // 记录正在编辑的任务ID
      siblingSourceTask: null, // 记录添加同级任务的源任务
      childSourceTask: null, // 记录添加子任务的源任务
      newTask: {
        name: '',
        parentId: null,
        newParentName: '',
        startDate: '',
        endDate: '',
        planStartDate: '',
        planEndDate: '',
        progress: 0,
        priority: 'medium',
        color: '#3498db',
        description: ''
      },

      // 拖拽排序实例
      sortableInstance: null,

      // 表格实例引用
      tableInstance: null,

      // 滚动同步锁
      scrollSyncLock: false,

      // 列配置拖拽排序实例
      columnSortableInstance: null,

      // 右侧区域实际宽度
      rightAreaWidth: 1200,

      // 性能优化相关
      useVirtualScrolling: false,
      performanceMonitorEnabled: true, // 始终显示性能监视器和设置按钮
      renderStartTime: 0,
      currentRenderTime: 0,

      // 虚拟滚动配置
      virtualScrollConfig: {
        itemHeight: 40,
        containerHeight: 600,
        bufferSize: 5
      },

      // 自动优化设置
      autoOptimizeConfig: {
        enabled: false,
        maxTasksBeforeVirtual: 500,
        maxRenderTime: 16, // 毫秒
        performanceCheckInterval: 5000 // 毫秒
      },

      // 性能指标
      performanceMetrics: {
        frameCount: 0,
        lastFrameTime: 0,
        averageRenderTime: 0,
        renderTimes: []
      },

      // 表格列配置（用于虚拟滚动）
      tableColumns: [
        { key: 'name', title: 'Task Name', width: 200, minWidth: 150, sortable: false, slot: 'name' },
        { key: 'progress', title: 'Progress', width: 100, minWidth: 80, sortable: true, slot: 'progress' },
        { key: 'startDate', title: 'Start Date', width: 120, minWidth: 100, sortable: true, format: 'date' },
        { key: 'endDate', title: 'End Date', width: 120, minWidth: 100, sortable: true, format: 'date' },
        { key: 'assignee', title: 'Assignee', width: 120, minWidth: 100, sortable: true },
        { key: 'status', title: 'Status', width: 100, minWidth: 80, sortable: true, slot: 'status' }
      ],

      // 拖拽滚动相关
      isDragging: false,
      dragStartX: 0,
      dragStartY: 0,
      scrollStartX: 0,
      scrollStartY: 0,
      dragTarget: null,
      leftPanelHeight: 600, // 新增，左侧面板实际高度

      // 甘特图显示配置
      ganttDisplayConfig: {
        showTaskName: true,
        showProgress: true,
        showProgressHandle: true,
        showConnections: true,
        showConnectionLabels: false,
        showPlanNodes: false,
        showMilestones: true,
        showCriticalPath: false,
        enableThreeLevelNodes: true,
        allowParentDrag: false, // 父节点是否可拖拽，默认不可拖拽
        allowParentEdit: false, // 父节点是否可编辑，默认不可编辑
        highlightTaskLineage: false // 点击节点是否高亮显示血缘关系

      },





      // 父节点拖拽防抖定时器
      parentDragDebounceTimer: null,

      // 时间轴强制刷新key
      timelineRefreshKey: 0
    }
  },
  computed: {
    ...mapState({
      ganttData: 'ganttData',
      storeViewMode: 'viewMode',  // 重命名避免冲突
      highlightedConnections: 'highlightedConnections',
      todayMarker: 'todayMarker',
      grayConnectionMode: 'grayConnectionMode'
    }),
    ...mapGetters(['visibleTasks', 'isTaskCollapsed', 'visibleColumns', 'isLeftPanelVisible', 'getTodayDate', 'isTodayMarkerEnabled']),

    // 本地控制的左侧面板可见性
    leftPanelVisible: {
      get() {
        return this.isLeftPanelVisible
      },
      set(value) {
        this.$store.dispatch('toggleLeftPanel', value)
      }
    },

    // 扁平化的任务数据，用于表格显示
    flatTableData() {
      return this.visibleTasks
    },

    // 扁平化的任务数据，用于甘特图显示
    flattenTasks() {
      return this.visibleTasks
    },

    // 动态列配置
    dynamicColumns() {
      return this.visibleColumns.filter(col =>
        col.id !== 'checkbox' && col.id !== 'taskName'
      )
    },

    // 可用列配置
    availableColumns() {
      // 从store获取完整的列配置，过滤掉固定列
      return this.$store.getters.getColumnConfig.filter(col =>
        col.id !== 'checkbox' && col.id !== 'taskName'
      )
    },

    // 基础日期范围计算（不依赖视图模式）
    baseDateRange() {
      if (this.dateRange && this.dateRange.length === 2 && this.dateRange[0] && this.dateRange[1]) {
        // 如果用户已经设置了日期范围，则使用用户设置的
        return this.dateRange
      }

      // 否则根据任务数据生成基础范围
      if (this.flattenTasks.length === 0) {
        // 如果没有任务，返回默认范围
        const today = moment()
        return [
          today.clone().subtract(30, 'days').format('YYYY-MM-DD'),
          today.clone().add(60, 'days').format('YYYY-MM-DD')
        ]
      }

      // 计算所有任务的时间范围
      let minDate = null
      let maxDate = null

      this.flattenTasks.forEach(task => {
        if (task.startDate) {
          const start = moment(task.startDate)
          if (!minDate || start.isBefore(minDate)) {
            minDate = start
          }
        }
        if (task.endDate) {
          const end = moment(task.endDate)
          if (!maxDate || end.isAfter(maxDate)) {
            maxDate = end
          }
        }
      })

      if (!minDate || !maxDate) {
        // 如果没有找到有效日期，返回默认范围
        const today = moment()
        return [
          today.clone().subtract(30, 'days').format('YYYY-MM-DD'),
          today.clone().add(60, 'days').format('YYYY-MM-DD')
        ]
      }

      // 基础范围：任务范围前后各加15天
      const adjustedStart = minDate.clone().subtract(15, 'days')
      const adjustedEnd = maxDate.clone().add(15, 'days')

      return [
        adjustedStart.format('YYYY-MM-DD'),
        adjustedEnd.format('YYYY-MM-DD')
      ]
    },

    // 自动计算最佳视图模式（基于基础日期范围）
    autoViewMode() {
      const range = this.baseDateRange
      const startDate = moment(range[0])
      const endDate = moment(range[1])
      const daysDiff = endDate.diff(startDate, 'days')
      const monthsDiff = endDate.diff(startDate, 'months')
      const yearsDiff = endDate.diff(startDate, 'years')

      // 根据时间跨度自动选择视图模式
      if (yearsDiff >= 2) {
        return 'year'
      } else if (monthsDiff >= 6) {
        return 'month'
      } else if (daysDiff > 60) {
        return 'month'
      } else {
        return 'day'
      }
    },

    // 当前使用的视图模式
    effectiveViewMode() {
      // 如果用户手动设置了日期范围，使用当前视图模式
      if (this.dateRange && this.dateRange.length > 0) {
        return this.currentViewMode
      }
      // 否则使用自动计算的视图模式
      return this.autoViewMode
    },

    // 根据视图模式调整的最终日期范围
    dynamicDateRange() {
      // 如果用户手动设置了日期范围，直接使用
      if (this.dateRange && this.dateRange.length === 2 && this.dateRange[0] && this.dateRange[1]) {
        return this.dateRange
      }

      // 获取基础范围
      const baseRange = this.baseDateRange
      const minDate = moment(baseRange[0])
      const maxDate = moment(baseRange[1])

      // 根据当前视图模式进行微调
      let adjustedStart, adjustedEnd
      const viewMode = this.effectiveViewMode

      switch (viewMode) {
      case 'day':
        // 日视图：在基础范围上微调
        adjustedStart = minDate.clone().subtract(7, 'days')
        adjustedEnd = maxDate.clone().add(7, 'days')
        break

      case 'month':
        // 月视图：对齐到月边界
        adjustedStart = minDate.clone().startOf('month')
        adjustedEnd = maxDate.clone().endOf('month')
        break

      case 'year':
        // 年视图：对齐到年边界
        adjustedStart = minDate.clone().startOf('year')
        adjustedEnd = maxDate.clone().endOf('year')
        break

      default:
        adjustedStart = minDate
        adjustedEnd = maxDate
      }

      return [
        adjustedStart.format('YYYY-MM-DD'),
        adjustedEnd.format('YYYY-MM-DD')
      ]
    },

    // 图表日期范围
    chartStartDate() {
      const range = this.dynamicDateRange
      return moment(range[0])
    },

    chartEndDate() {
      const range = this.dynamicDateRange
      return moment(range[1])
    },

    // 是否是手动设置的日期范围
    isManualDateRange() {
      return !!(this.dateRange && this.dateRange.length > 0)
    },

    // 预定义颜色
    predefineColors() {
      return [
        '#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6',
        '#1abc9c', '#34495e', '#e67e22', '#8e44ad', '#27ae60'
      ]
    },

    // 对话框标题
    dialogTitle() {
      switch (this.dialogMode) {
      case 'edit':
        return 'Edit Task'
      case 'add-sibling':
        return `Add Sibling Task (Sibling to: ${this.siblingSourceTask?.name || ''})`
      case 'add-child':
        return `Add Child Task (Parent: ${this.childSourceTask?.name || ''})`
      case 'add':
      default:
        return 'Add New Task'
      }
    },

    // 对话框按钮文本
    dialogButtonText() {
      switch (this.dialogMode) {
      case 'edit':
        return 'Save Changes'
      case 'add-sibling':
        return 'Add Sibling Task'
      case 'add-child':
        return 'Add Child Task'
      case 'add':
      default:
        return 'Add Task'
      }
    },

    // 是否显示父任务选择器
    shouldShowParentSelection() {
      return this.dialogMode === 'add' || this.dialogMode === 'edit'
    },

    // 是否显示父任务只读显示
    shouldShowParentDisplay() {
      return this.dialogMode === 'add-sibling' || this.dialogMode === 'add-child'
    },

    // 父任务显示名称
    parentTaskDisplayName() {
      if (this.dialogMode === 'add-child' && this.childSourceTask) {
        return this.childSourceTask.name
      } else if (this.dialogMode === 'add-sibling' && this.siblingSourceTask) {
        // 查找同级任务的父任务名称
        if (this.siblingSourceTask.parentId) {
          const parentTask = this.findTaskById(this.siblingSourceTask.parentId)
          return parentTask ? parentTask.name : '未找到父任务'
        } else {
          return '根级任务'
        }
      }
      return ''
    },

    // 表格高度 - 精确计算可视区域高度
    tableHeight() {
      // 获取ganttMain的实际高度，减去控制区高度
      if (this.$refs.ganttMain && this.$refs.ganttMain.clientHeight > 0) {
        const mainHeight = this.$refs.ganttMain.clientHeight
        const controlsHeight = 0 // 控制面板已移除
        const availableHeight = mainHeight - controlsHeight
        return Math.max(availableHeight, 300)
      }
      return 500
    },

    // 表单验证规则
    taskFormRules() {
      return {
        name: [
          { required: true, message: 'Please enter task name', trigger: 'blur' },
          { min: 1, max: 100, message: 'Task name length should be 1-100 characters', trigger: 'blur' }
        ],
        startDate: [
          { required: true, message: 'Please select start date', trigger: 'change' }
        ],
        endDate: [
          { required: true, message: 'Please select end date', trigger: 'change' }
        ],
        newParentName: [
          {
            validator: (rule, value, callback) => {
              if (this.newTask.parentId === 'new_parent') {
                if (!value || value.trim() === '') {
                  callback(new Error('Please enter parent group name'))
                } else if (value.length > 50) {
                  callback(new Error('Parent name length should be less than 50 characters'))
                } else {
                  callback()
                }
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ]
      }
    },

    // 父级任务选项 - 显示实际任务名称
    parentTaskOptions() {
      const options = []
      const rootTasks = this.ganttData || []

      // 创建所有任务的扁平化列表，用于父任务选择
      const getAllTasks = (tasks) => {
        let allTasks = []
        tasks.forEach(task => {
          // 排除当前正在编辑的任务（防止自己作为自己的父任务）
          if (this.dialogMode === 'edit' && task.id === this.editingTaskId) {
            return
          }
          allTasks.push(task)
          if (task.children) {
            allTasks = allTasks.concat(getAllTasks(task.children))
          }
        })
        return allTasks
      }

      const allTasks = getAllTasks(rootTasks)

      // 按层级分组添加父任务选项
      if (allTasks.length > 0) {
        // 根级任务（没有父任务的任务）
        const rootLevelTasks = allTasks.filter(task => !task.parentId)
        if (rootLevelTasks.length > 0) {
          options.push({
            label: '根级任务',
            options: rootLevelTasks.map(task => ({
              label: task.name,
              value: task.id
            }))
          })
        }

        // 有子任务的任务（可以作为父任务）
        const parentTasks = allTasks.filter(task => task.children && task.children.length > 0)
        if (parentTasks.length > 0) {
          options.push({
            label: '父级任务组',
            options: parentTasks.map(task => ({
              label: task.name,
              value: task.id
            }))
          })
        }
      }

      return options
    },

    // 结束日期选择器选项
    endDatePickerOptions() {
      return {
        disabledDate: (time) => {
          if (!this.newTask.startDate) return false
          return time.getTime() < new Date(this.newTask.startDate).getTime()
        }
      }
    },

    // 计划结束日期选择器选项
    planEndDatePickerOptions() {
      return {
        disabledDate: (time) => {
          if (!this.newTask.planStartDate) return false
          return time.getTime() < new Date(this.newTask.planStartDate).getTime()
        }
      }
    },

    // 决定是否使用虚拟滚动
    shouldUseVirtualScrolling() {
      return this.useVirtualScrolling || (
        this.autoOptimizeConfig.enabled &&
        this.flattenTasks.length > this.autoOptimizeConfig.maxTasksBeforeVirtual
      )
    },

    // 可见任务数量（用于性能监控）
    visibleTaskCount() {
      return this.flattenTasks.filter(task => {
        // 计算当前视口中可见的任务数量
        return true // 简化实现，实际应该根据滚动位置计算
      }).length
    },

    // 平铺表格数据（用于虚拟滚动）
    flatTableDataForVirtual() {
      // 直接用所有已展开的可见任务
      return this.visibleTasks.map(task => ({
        ...task,
        id: task.id || Math.random().toString(36).substr(2, 9)
      }))
    },

    // 动态虚拟滚动容器高度
    dynamicVirtualScrollHeight() {
      // 计算实际内容高度，确保与甘特图右侧内容高度一致
      const contentHeight = Math.max(this.flattenTasks.length * 40, 200)
      // 不超过可用的容器高度
      return Math.min(contentHeight, this.tableHeight)
    },

    // 计算实际需要的甘特图高度
    actualGanttHeight() {
      // 基于扁平化任务数量计算实际高度，每个任务40px行高
      const taskCount = this.flattenTasks.length
      const calculatedHeight = Math.max(taskCount * 40, 200) // 最小200px

      // 如果任务数量较少，避免过多空白区域
      if (taskCount <= 5) {
        return Math.max(taskCount * 40, 200)
      }

      return calculatedHeight
    },

    // 动态甘特图最小高度CSS变量
    ganttHeightStyle() {
      return {
        '--gantt-min-height': `${this.actualGanttHeight  }px`
      }
    }
  },
  methods: {
    ...mapActions(['toggleTaskCollapsed', 'jumpToToday', 'clearLineageHighlight', 'setLineageHighlight']),

    // 切换关键路径显示
    toggleCriticalPath() {
      this.ganttDisplayConfig.showCriticalPath = !this.ganttDisplayConfig.showCriticalPath

      // 通知设置对话框更新配置
      this.$emit('gantt-display-config-change', this.ganttDisplayConfig)

      // 显示消息提示
      this.$message({
        message: `${this.ganttDisplayConfig.showCriticalPath ? '显示' : '隐藏'}关键路径`,
        type: 'success',
        duration: 1500
      })
    },

    // 处理节点拖拽请求平移视图
    handleRequestPan(panRequest) {
      if (panRequest.direction === 'right') {
        // 向右平移视图（内容向左移动）
        this.panOffset += panRequest.amount
      } else if (panRequest.direction === 'left') {
        // 向左平移视图（内容向右移动）
        this.panOffset -= panRequest.amount
      }

      // 如果需要更新时间轴
      if (panRequest.updateTimeline) {
        if (panRequest.extendLeft) {
          // 向左扩展时间轴（增加更早的日期）
          const currentStartDate = this.chartStartDate.clone()
          // 根据视图模式决定扩展的天数
          let daysToExtend = 7 // 默认扩展一周

          if (this.effectiveViewMode === 'day') {
            daysToExtend = 7
          } else if (this.effectiveViewMode === 'week') {
            daysToExtend = 14
          } else if (this.effectiveViewMode === 'month') {
            daysToExtend = 30
          }

          // 更新开始日期
          this.chartStartDate = currentStartDate.subtract(daysToExtend, 'days')

          // 直接更新时间轴刷新键，而不是调用可能不存在的方法
          this.timelineRefreshKey = Date.now()
        } else if (panRequest.extendRight) {
          // 向右扩展时间轴（增加更晚的日期）
          const currentEndDate = this.chartEndDate.clone()
          // 根据视图模式决定扩展的天数
          let daysToExtend = 7 // 默认扩展一周

          if (this.effectiveViewMode === 'day') {
            daysToExtend = 7
          } else if (this.effectiveViewMode === 'week') {
            daysToExtend = 14
          } else if (this.effectiveViewMode === 'month') {
            daysToExtend = 30
          }

          // 更新结束日期
          this.chartEndDate = currentEndDate.add(daysToExtend, 'days')

          // 直接更新时间轴刷新键，而不是调用可能不存在的方法
          this.timelineRefreshKey = Date.now()
        }
      }

      // 更新时间轴和网格的位置
      this.timelineRefreshKey = Date.now()

      // 强制更新视图
      this.$nextTick(() => {
        this.$forceUpdate()
      })
    },

    // 处理甘特图宽度更新请求
    handleUpdateChartWidth(updateInfo) {
      console.log('[宽度更新] 收到宽度更新请求:', updateInfo)

      // 根据方向和数量更新甘特图宽度
      if (updateInfo.direction === 'left') {
        // 向左扩展甘特图宽度，需要增加左侧空间
        this.updateRightAreaWidth()
        console.log('[宽度更新] 向左扩展，重新计算宽度')
      } else if (updateInfo.direction === 'right') {
        // 向右扩展甘特图宽度，立即增加足够的宽度
        const expandAmount = Math.max(updateInfo.amount * 3, 500) // 确保足够的扩展空间
        this.rightAreaWidth += expandAmount
        console.log('[宽度更新] 向右扩展，增加宽度:', expandAmount, '新宽度:', this.rightAreaWidth)

        // 同时检查是否需要扩展时间轴日期范围
        const currentEndDate = this.chartEndDate
        const daysToAdd = Math.ceil(expandAmount / this.getDayWidth())
        const newEndDate = currentEndDate.clone().add(daysToAdd + 15, 'days') // 额外增加15天缓冲

        console.log('[时间轴扩展] 准备扩展时间轴，增加天数:', daysToAdd + 15)

        // 更新日期范围以支持向右扩展
        this.dateRange = [
          this.chartStartDate.format('YYYY-MM-DD'),
          newEndDate.format('YYYY-MM-DD')
        ]
      }

      // 强制更新所有相关组件
      this.$nextTick(() => {
        // 重新计算宽度确保一致性
        this.updateRightAreaWidth()

        // 强制更新主要组件
        this.$forceUpdate()

        // 更新时间轴和甘特图组件
        if (this.$refs.timeline) {
          this.$refs.timeline.$forceUpdate()
        }
        if (this.$refs.ganttBars) {
          this.$refs.ganttBars.$forceUpdate()
        }

        console.log('[宽度更新] 组件更新完成，最终宽度:', this.rightAreaWidth)
      })
    },

    // 显示设置对话框
    openSettingsDialog() {
      this.$emit('update:showSettingsDialog', true)
    },

    // 处理设置对话框可见性变化
    handleSettingsVisibleChange(visible) {
      this.$emit('update:showSettingsDialog', visible)
      if (!visible) {
        this.$emit('settings-dialog-close')
      }
    },

    // 甘特图显示配置变更处理
    handleGanttDisplayConfigChange(config) {
      this.ganttDisplayConfig = { ...config }
    },

    // 处理连接线编辑配置变化
    handleConnectionEditableChange(editable) {
      // 通知父组件连接线编辑配置已更改
      this.$emit('connection-editable-change', editable)
    },

    // 处理设置保存
    handleSettingsSave(settings) {
      // 批量更新设置
      this.dateRange = settings.dateRange
      this.$emit('update:tooltipEnabled', settings.tooltipEnabled)
      this.$emit('update:tooltipDelay', settings.tooltipDelay)
      this.$emit('update:tooltipHideDelay', settings.tooltipHideDelay)
      this.$emit('update:timelineVisible', settings.timelineVisible)

      if (settings.grayConnectionMode !== this.grayConnectionMode) {
        this.toggleGrayConnectionMode()
      }

      if (settings.autoOptimizeEnabled !== this.autoOptimizeConfig.enabled) {
        this.handleAutoOptimizeToggle(settings.autoOptimizeEnabled)
      }

      // 更新甘特图显示配置
      if (settings.ganttDisplayConfig) {
        this.ganttDisplayConfig = { ...settings.ganttDisplayConfig }
      }

      this.$message.success('Settings saved successfully')
    },

    // 更新tooltip延迟设置
    updateTooltipDelay(value) {
      this.$emit('update:tooltipDelay', value)
    },

    updateTooltipHideDelay(value) {
      this.$emit('update:tooltipHideDelay', value)
    },

    updateTimelineVisible(value) {
      this.$emit('update:timelineVisible', value)
    },

    // 更新右侧区域宽度
    updateRightAreaWidth() {
      const totalDays = this.chartEndDate.diff(this.chartStartDate, 'days') + 1
      const dayWidth = this.getDayWidth()
      const containerWidth = this.$refs.ganttRight?.clientWidth || 0

      // 计算所有任务中最大的结束日期
      let maxEndDate = this.chartEndDate.clone()

      // 遍历所有任务找到最大结束日期
      this.flattenTasks.forEach(task => {
        if (task.endDate) {
          const taskEndDate = moment(task.endDate)
          if (taskEndDate.isAfter(maxEndDate)) {
            maxEndDate = taskEndDate.clone()
          }
        }
      })

      // 计算最大结束日期与当前图表结束日期的差值
      const extraDays = Math.max(0, maxEndDate.diff(this.chartEndDate, 'days'))

      // 如果有任务超出当前结束日期，增加额外的宽度
      const contentWidth = (totalDays + extraDays) * dayWidth

      // 根据视图模式调整最小宽度
      let minWidth = 800
      switch(this.effectiveViewMode) {
      case 'day':
        minWidth = 1200 // 日视图需要更宽的空间
        break
      case 'week':
        minWidth = 1000
        break
      case 'month':
        minWidth = 800
        break
      case 'year':
        minWidth = 600 // 年视图可以更紧凑
        break
      }

      // 设置最终宽度，确保足够容纳所有任务和拖拽操作
      // 增加适当的缓冲空间以支持向右拖拽和动态渲染
      const bufferWidth = 200 // 适中的缓冲空间，支持向右拖拽时的动态扩展
      this.rightAreaWidth = Math.max(contentWidth + bufferWidth, containerWidth, minWidth)

      console.log(`[宽度计算] 视图模式: ${this.effectiveViewMode}, 总天数: ${totalDays}, 额外天数: ${extraDays}, 天宽度: ${dayWidth}px, 内容宽度: ${contentWidth}px, 容器宽度: ${containerWidth}px, 最终宽度: ${this.rightAreaWidth}px`)

      // 如果有任务超出当前日期范围，考虑自动扩展日期范围
      if (extraDays > 0) {
        console.log(`[日期范围] 检测到任务超出当前日期范围 ${extraDays} 天，自动调整时间轴`)
      }

      this.$nextTick(() => this.$forceUpdate())
    },

    // 日期格式化
    formatDate(date) {
      if (!date) return '-'
      return moment(date).format('MM/DD/YYYY')
    },

    // 获取任务状态
    getTaskStatus(task) {
      if (!task.progress) return 'Not Started'
      if (task.progress >= 100) return 'Completed'
      if (task.progress > 0) return 'In Progress'
      return 'Not Started'
    },

    // 获取状态样式类
    getStatusClass(task) {
      const status = this.getTaskStatus(task)
      return {
        'status-completed': status === 'Completed',
        'status-progress': status === 'In Progress',
        'status-not-started': status === 'Not Started'
      }
    },

    // 获取行样式类
    getRowClassName({ row, rowIndex }) {
      let className = ''
      if (row.children && row.children.length > 0) {
        className += 'parent-row '
      }
      if (this.highlightedRowId === row.id) {
        className += 'highlighted-row '
      }
      return className
    },

    // 处理折叠/展开
    handleToggleCollapse(taskId) {
      // 调用store action（确保状态更新）
      this.toggleTaskCollapsed(taskId)

      // 强制右侧甘特图组件更新
      this.$nextTick(() => {
        // 触发右侧组件重新渲染
        if (this.$refs.ganttRight) {
          this.$forceUpdate()
        }
      })
    },

    // 处理行点击
    handleRowClick(row) {
      this.highlightedRowId = row.id
    },

    // 处理右侧滚动
    handleRightScroll(event) {
      // 如果正在拖拽，不处理滚动同步
      // 拖拽时的滚动变化由拖拽逻辑单独处理
      if (this.isDragging) {
        return
      }

      const {scrollLeft} = event.target
      const {scrollTop} = event.target

      // 防止滚动循环同步
      if (this.scrollSyncLock) return
      this.scrollSyncLock = true

      // 延迟执行同步，确保当前滚动事件处理完成
      this.$nextTick(() => {
        this.performScrollSync(scrollLeft, scrollTop, 'right')

        // 释放锁
        this.scrollSyncLock = false
      })
    },

    // 统一的滚动同步方法
    performScrollSync(scrollLeft, scrollTop, source = 'unknown') {
      if (this.shouldUseVirtualScrolling) {
        // 虚拟滚动表格同步
        const {virtualTable} = this.$refs
        if (virtualTable) {
          // 同步水平滚动
          const virtualTableContainer = virtualTable.$refs?.container
          if (virtualTableContainer && Math.abs(virtualTableContainer.scrollLeft - scrollLeft) > 1) {
            virtualTableContainer.scrollLeft = scrollLeft
          }

          // 同步垂直滚动 - 优先使用scrollTo方法
          if (virtualTable.scrollTo && Math.abs((virtualTable.scrollData?.scrollTop || 0) - scrollTop) > 1) {
            virtualTable.scrollTo(scrollTop)
          } else {
            const virtualTableBody = virtualTable.$refs?.body
            if (virtualTableBody && Math.abs(virtualTableBody.scrollTop - scrollTop) > 1) {
              virtualTableBody.scrollTop = scrollTop
            }
          }
        }
      } else {
        // 普通表格同步
        const {customTable} = this.$refs
        if (customTable) {
          const customTableBody = customTable.$refs?.tableBody
          if (customTableBody) {
            if (Math.abs(customTableBody.scrollLeft - scrollLeft) > 1) {
              customTableBody.scrollLeft = scrollLeft
            }
            if (Math.abs(customTableBody.scrollTop - scrollTop) > 1) {
              customTableBody.scrollTop = scrollTop
            }
          }
        }
      }
    },

    // 空操作
    noop() {},
    // 处理图表区域点击
    handleChartAreaClick() {
      this.highlightedRowId = null
      // 清除连接高亮
      this.$store.dispatch('clearLineageHighlight')
    },

    // 处理任务栏拖拽
    handleBarDrag(payload) {
      // 父节点拖拽时使用requestAnimationFrame和更短防抖
      if (payload.isParentNode) {
        if (this.parentDragDebounceTimer) {
          cancelAnimationFrame(this.parentDragDebounceTimer)
        }
        this.parentDragDebounceTimer = requestAnimationFrame(() => {
          this.$store.dispatch('updateGanttItem', payload)

          // 检查并更新甘特图宽度和时间轴
          this.checkAndUpdateChartWidth(payload)
        })
      } else {
        this.$store.dispatch('updateGanttItem', payload)

        // 检查并更新甘特图宽度和时间轴
        this.checkAndUpdateChartWidth(payload)
      }
    },

    // 处理任务栏调整大小
    handleBarResize(payload) {
      this.$store.dispatch('updateGanttItem', payload)
      // 自定义表格会自动响应store变化，不需要强制刷新

      // 检查并更新甘特图宽度和时间轴
      this.checkAndUpdateChartWidth(payload)
    },

    // 检查并更新甘特图宽度和时间轴
    checkAndUpdateChartWidth(payload) {
      // 使用nextTick确保状态已更新
      this.$nextTick(() => {
        // 更新甘特图宽度
        this.updateRightAreaWidth()

        // 如果任务移动超出当前日期范围，自动扩展日期范围
        let needsUpdate = false
        let newStartDate = this.chartStartDate.clone()
        let newEndDate = this.chartEndDate.clone()

        // 检查开始日期（向左扩展）
        if (payload.startDate) {
          const taskStartMoment = moment(payload.startDate)
          if (taskStartMoment.isBefore(this.chartStartDate)) {
            newStartDate = taskStartMoment.clone().subtract(15, 'days') // 额外增加15天缓冲
            needsUpdate = true
            console.log('[日期范围] 任务超出左边界，自动扩展开始日期到:', newStartDate.format('YYYY-MM-DD'))
          }
        }

        // 检查结束日期（向右扩展）
        if (payload.endDate) {
          const taskEndMoment = moment(payload.endDate)
          if (taskEndMoment.isAfter(this.chartEndDate)) {
            newEndDate = taskEndMoment.clone().add(15, 'days') // 额外增加15天缓冲
            needsUpdate = true
            console.log('[日期范围] 任务超出右边界，自动扩展结束日期到:', newEndDate.format('YYYY-MM-DD'))
          }
        }

        if (needsUpdate) {
          // 更新日期范围
          this.dateRange = [
            newStartDate.format('YYYY-MM-DD'),
            newEndDate.format('YYYY-MM-DD')
          ]

          console.log('[时间轴更新] 日期范围已更新，正在刷新时间轴组件')

          // 立即更新右侧区域宽度以支持向右拖拽
          this.updateRightAreaWidth()

          // 强制刷新时间轴组件 - 使用多重刷新确保正确渲染
          this.$nextTick(() => {
            // 再次确保右侧区域宽度正确
            this.updateRightAreaWidth()

            // 刷新时间轴组件
            if (this.$refs.timeline) {
              // 先更新时间轴的实际宽度
              if (this.$refs.timeline.updateActualWidth) {
                this.$refs.timeline.updateActualWidth()
              }
              // 然后强制更新组件
              this.$refs.timeline.$forceUpdate()
              console.log('[时间轴更新] 时间轴组件已强制更新')
            }

            // 强制更新甘特图主要组件
            this.$forceUpdate()

            // 再次在下一个tick中确保所有变化都已应用
            this.$nextTick(() => {
              if (this.$refs.timeline) {
                this.$refs.timeline.$forceUpdate()
              }
              // 确保甘特图内容区域也正确更新
              if (this.$refs.ganttBars) {
                this.$refs.ganttBars.$forceUpdate()
              }
            })
          })
        }
      })
    },

    // 处理任务更新
    handleTaskUpdate(payload) {
      this.$store.dispatch('updateGanttItem', payload)
      // 自定义表格会自动响应store变化，不需要强制刷新
      this.autoRangeDebounced() // 修改后自动 range
    },

    // 处理任务删除
    handleTaskDelete(taskId) {
      this.$store.dispatch('deleteTask', taskId)
      this.autoRangeDebounced() // 删除后自动 range
    },

    // 处理任务高亮
    handleTaskHighlight(taskId) {
      this.highlightedRowId = taskId
    },

    // 更新日期范围
    handleDateRangeChange(range) {
      this.dateRange = range
      // 当用户手动设置日期范围时，启用视图模式选择
      if (range && range.length === 2) {
        // 保持当前视图模式
      } else {
        // 如果清空了日期范围，回到自动模式
        this.$emit('update:currentViewMode', this.autoViewMode)
      }
    },

    // 重置日期范围到自动模式
    resetDateRange() {
      this.dateRange = []
      // 当重置日期范围时，自动选择合适的视图模式
      this.$nextTick(() => {
        this.$emit('update:currentViewMode', this.autoViewMode)
      })
    },

    // 显示添加任务对话框
    showAddTaskDialog() {
      this.resetTaskForm()
      this.showAddDialog = true
      // 设置默认开始日期为今天
      this.newTask.startDate = moment().format('YYYY-MM-DD')
      this.newTask.endDate = moment().add(7, 'days').format('YYYY-MM-DD')
    },

    // 切换tooltip显示
    toggleTooltip(enabled) {
      // 处理从SettingsDialog传递的布尔值或事件对象
      const isEnabled = typeof enabled === 'boolean' ? enabled : enabled.target.checked
      this.$emit('update:tooltipEnabled', isEnabled)
      this.$message({
        message: `Tooltips ${isEnabled ? 'enabled' : 'disabled'}`,
        type: 'info',
        duration: 1500
      })
    },

    // 拖拽滚动 - 开始拖拽
    handleDragStart(event) {
      // 只在左键点击时开始拖拽
      if (event.button !== 0) return

      // 检查是否点击在空白区域（避免干扰其他交互）
      const {target} = event

      // 更精确的检查，避免干扰任务栏、连接线、时间轴等交互元素
      const excludeSelectors = [
        '.gantt-bar', '.bar-progress', '.bar-resize-handle',
        '.dependency-line', '.dependency-arrow', '.dependency-label',
        '.scale-item', '.timeline-scale-top', '.timeline-scale-bottom',
        'input', 'button', 'select', '.el-button', '.el-input',
        '.grid-line', '.task-milestone'
      ]

      // 检查是否点击了排除的元素
      const isExcluded = excludeSelectors.some(selector => {
        return target.closest(selector) || target.matches(selector)
      })

      if (isExcluded) {
        return
      }

      // 添加延迟，避免与双击等事件冲突
      setTimeout(() => {
        if (!this.isDragging) { // 确保在延迟期间没有被其他事件取消
          this.isDragging = true
          this.dragStartX = event.clientX
          this.dragStartY = event.clientY
          this.dragTarget = this.$refs.scrollContainer

          if (this.dragTarget) {
            this.scrollStartX = this.dragTarget.scrollLeft
            this.scrollStartY = this.dragTarget.scrollTop
          }

          // 改变鼠标样式
          document.body.style.cursor = 'grabbing'
          document.body.style.userSelect = 'none'
        }
      }, 50) // 50ms延迟

      // 阻止默认行为
      event.preventDefault()
    },

    // 拖拽滚动 - 拖拽移动
    handleDragMove(event) {
      if (!this.isDragging || !this.dragTarget) return

      const deltaX = this.dragStartX - event.clientX
      const deltaY = this.dragStartY - event.clientY

      // 计算新的滚动位置
      const newScrollLeft = this.scrollStartX + deltaX
      const newScrollTop = this.scrollStartY + deltaY

      // 更新滚动位置
      this.dragTarget.scrollLeft = newScrollLeft
      this.dragTarget.scrollTop = newScrollTop

      // 甘特图拖拽只同步垂直滚动，不同步水平滚动
      // 因为拖拽是为了平移时间轴，不是为了查看表格的更多列
      this.syncLeftTableScrollVerticalOnly(newScrollTop)

      event.preventDefault()
    },

    // 同步左侧表格滚动（供拖拽滚动使用）
    syncLeftTableScroll(scrollLeft, scrollTop) {
      // 防止滚动循环同步
      if (this.scrollSyncLock) return
      this.scrollSyncLock = true

      // 使用统一的同步方法
      this.$nextTick(() => {
        this.performScrollSync(scrollLeft, scrollTop, 'drag')

        // 释放锁
        this.scrollSyncLock = false
      })
    },

    // 仅同步左侧表格的垂直滚动（供甘特图拖拽使用）
    syncLeftTableScrollVerticalOnly(scrollTop) {
      // 防止滚动循环同步
      if (this.scrollSyncLock) return
      this.scrollSyncLock = true

      this.$nextTick(() => {
        // 只同步垂直滚动，不同步水平滚动
        if (this.shouldUseVirtualScrolling) {
          // 虚拟滚动表格同步
          const {virtualTable} = this.$refs
          if (virtualTable) {
            // 同步垂直滚动 - 优先使用scrollTo方法
            if (virtualTable.scrollTo && Math.abs((virtualTable.scrollData?.scrollTop || 0) - scrollTop) > 1) {
              virtualTable.scrollTo(scrollTop)
            } else {
              const virtualTableBody = virtualTable.$refs?.body
              if (virtualTableBody && Math.abs(virtualTableBody.scrollTop - scrollTop) > 1) {
                virtualTableBody.scrollTop = scrollTop
              }
            }
          }
        } else {
          // 普通表格同步
          const {customTable} = this.$refs
          if (customTable) {
            const customTableBody = customTable.$refs?.tableBody
            if (customTableBody && Math.abs(customTableBody.scrollTop - scrollTop) > 1) {
              customTableBody.scrollTop = scrollTop
            }
          }
        }

        // 释放锁
        this.scrollSyncLock = false
      })
    },

    // 拖拽滚动 - 结束拖拽
    handleDragEnd(event) {
      if (!this.isDragging) return
      this.isDragging = false
      this.dragTarget = null
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
      if (this.parentDragDebounceTimer) {
        cancelAnimationFrame(this.parentDragDebounceTimer)
        this.parentDragDebounceTimer = null
      }
      event.preventDefault()
    },

    // 导出数据
    exportData() {
      // 导出甘特图数据
      const data = {
        ganttData: this.$store.state.ganttData,
        dependencies: this.$store.state.dependencies
      }
      const dataStr = JSON.stringify(data, null, 2)
      const dataBlob = new Blob([dataStr], { type: 'application/json' })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement('a')
      link.href = url
      link.download = 'gantt-data.json'
      link.click()
      URL.revokeObjectURL(url)
    },

    // 显示列配置对话框
    showColumnConfigDialog() {
      this.showColumnDialog = true
      // 在下一个tick初始化拖拽排序
      this.$nextTick(() => {
        this.initColumnConfigSortable()
      })
    },

    // 初始化列配置表格的拖拽排序
    initColumnConfigSortable() {
      if (!this.$refs.columnConfigTable || !this.$refs.columnConfigTable.$el) return

      const tbody = this.$refs.columnConfigTable.$el.querySelector('.el-table__body-wrapper tbody')
      if (!tbody) return

      // 销毁现有的排序实例
      if (this.columnSortableInstance) {
        this.columnSortableInstance.destroy()
      }

      this.columnSortableInstance = Sortable.create(tbody, {
        animation: 150,
        handle: '.drag-handle-column',
        onEnd: (evt) => {
          this.handleColumnConfigReorder(evt.oldIndex, evt.newIndex)
        }
      })
    },

    // 处理列配置重新排序
    handleColumnConfigReorder(oldIndex, newIndex) {
      if (oldIndex === newIndex) return

      // 获取当前的列配置数组（创建副本）
      const columns = JSON.parse(JSON.stringify(this.availableColumns))

      // 重新排序
      const movedColumn = columns.splice(oldIndex, 1)[0]
      columns.splice(newIndex, 0, movedColumn)

      // 更新order属性
      columns.forEach((col, index) => {
        col.order = index
      })

      // 更新store
      this.$store.dispatch('updateColumnConfig', columns)

      // 强制刷新
      this.$forceUpdate()

      // 重新初始化拖拽
      this.$nextTick(() => {
        this.initColumnConfigSortable()
      })
    },

    // 编辑任务
    editTask(task) {
      console.log('编辑任务:', task)

      // 设置编辑模式
      this.dialogMode = 'edit'
      this.editingTaskId = task.id

      // 预填充任务数据，包括正确的父任务信息，确保父任务自动选中且可修改
      this.newTask = {
        name: task.name || '',
        parentId: task.parentId || null, // 自动选中当前任务的父任务
        newParentName: '',
        startDate: task.startDate || '',
        endDate: task.endDate || '',
        planStartDate: task.planStartDate || '',
        planEndDate: task.planEndDate || '',
        progress: task.progress || 0,
        priority: task.priority || 'medium',
        color: task.color || '#3498db',
        description: task.description || ''
      }

      // 打开对话框
      this.showAddDialog = true
    },

    // 添加同级任务
    addSiblingTask(task) {
      console.log('添加同级任务:', task)

      // 设置同级添加模式
      this.dialogMode = 'add-sibling'
      this.siblingSourceTask = task

      // 预填充父级任务信息和推荐日期
      const siblingEndDate = task.endDate ? moment(task.endDate) : moment()
      const recommendedStartDate = siblingEndDate.clone().add(1, 'day')
      const recommendedEndDate = recommendedStartDate.clone().add(
        task.endDate && task.startDate ?
          moment(task.endDate).diff(moment(task.startDate), 'days') : 7,
        'days'
      )

      this.newTask = {
        name: '',
        parentId: task.parentId || null, // 与源任务同一父级，自动选中且不可修改
        newParentName: '',
        startDate: recommendedStartDate.format('YYYY-MM-DD'),
        endDate: recommendedEndDate.format('YYYY-MM-DD'),
        planStartDate: '',
        planEndDate: '',
        progress: 0,
        priority: task.priority || 'medium', // 沿用源任务优先级
        color: task.color || '#3498db', // 沿用源任务颜色
        description: ''
      }

      // 打开对话框
      this.showAddDialog = true
    },

    // 添加子任务
    addChildTask(task) {
      console.log('添加子任务:', task)

      // 设置子任务添加模式
      this.dialogMode = 'add-child'
      this.childSourceTask = task

      // 预填充父级为当前任务，并设置推荐日期
      const parentStartDate = task.startDate ? moment(task.startDate) : moment()
      const parentEndDate = task.endDate ? moment(task.endDate) : moment().add(7, 'days')

      // 子任务建议在父任务时间范围内
      const recommendedStartDate = parentStartDate.clone()
      const recommendedEndDate = parentStartDate.clone().add(
        Math.max(1, Math.floor(parentEndDate.diff(parentStartDate, 'days') / 3)),
        'days'
      )

      this.newTask = {
        name: '',
        parentId: task.id, // 父级为当前任务
        newParentName: '',
        startDate: recommendedStartDate.format('YYYY-MM-DD'),
        endDate: recommendedEndDate.format('YYYY-MM-DD'),
        planStartDate: '',
        planEndDate: '',
        progress: 0,
        priority: task.priority || 'medium', // 沿用父任务优先级
        color: task.color || '#3498db', // 沿用父任务颜色
        description: ''
      }

      // 打开对话框
      this.showAddDialog = true
    },

    // 删除任务
    deleteTask(task) {
      this.$store.dispatch('deleteTask', task.id)
      this.autoRangeDebounced() // 删除后自动 range
    },

    // 开始调整大小
    startResize(event) {
      this.isResizing = true
      this.startX = event.clientX
      this.startWidth = this.leftWidth

      // 添加鼠标移动和释放事件监听
      document.addEventListener('mousemove', this.handleResize)
      document.addEventListener('mouseup', this.endResize)

      event.preventDefault()
    },

    // 处理调整大小
    handleResize(event) {
      if (!this.isResizing) return

      const deltaX = event.clientX - this.startX
      const newWidth = Math.max(200, Math.min(600, this.startWidth + deltaX))
      this.leftWidth = newWidth
    },

    // 结束调整大小
    endResize() {
      this.isResizing = false
      document.removeEventListener('mousemove', this.handleResize)
      document.removeEventListener('mouseup', this.endResize)

      // 大小调整完成后更新右侧宽度
      this.$nextTick(() => {
        this.updateRightAreaWidth()
      })
    },

    // 切换左侧面板
    toggleLeftPanel() {
      this.$store.dispatch('toggleLeftPanel')
      // 面板切换后更新右侧宽度
      this.$nextTick(() => {
        setTimeout(() => {
          this.updateRightAreaWidth()
        }, 300) // 等待过渡动画完成
      })
    },

    // 更新列可见性
    updateColumnVisibility(column) {
      this.$store.dispatch('updateColumnVisibility', {
        id: column.id,
        visible: column.visible
      })
    },

    // 更新列宽度
    updateColumnWidth(column) {
      this.$store.dispatch('updateColumnWidth', {
        id: column.id,
        width: column.width
      })
    },

    // 保存列配置
    saveColumnConfig() {
      this.showColumnDialog = false
      this.$message.success('Column configuration saved!')
    },

    // 添加新任务
    addNewTask() {
      this.$refs.addTaskForm.validate(async (valid) => {
        if (!valid) {
          this.$message.error('请正确填写所有必填字段')
          return false
        }

        this.addingTask = true

        try {
          // 验证日期逻辑
          if (moment(this.newTask.startDate).isAfter(moment(this.newTask.endDate))) {
            this.$message.error('开始日期不能晚于结束日期!')
            return false
          }

          // 验证计划日期逻辑
          if (this.newTask.planStartDate && this.newTask.planEndDate) {
            if (moment(this.newTask.planStartDate).isAfter(moment(this.newTask.planEndDate))) {
              this.$message.error('计划开始日期不能晚于计划结束日期!')
              return false
            }
          }

          // 根据对话框模式执行不同逻辑
          if (this.dialogMode === 'edit') {
            // 编辑任务逻辑
            await this.updateExistingTask()
            return
          }

          // 生成任务ID
          const taskId = Date.now() + Math.floor(Math.random() * 1000)

          // 处理父级任务逻辑
          let parentTask = null
          let newParentTask = null
          let insertPosition = null

          if (this.newTask.parentId === 'new_parent') {
            // 创建新的父级任务组
            const parentId = Date.now() + Math.floor(Math.random() * 10000)
            newParentTask = {
              id: parentId,
              name: this.newTask.newParentName.trim(),
              children: [],
              level: 0,
              color: this.newTask.color,
              isParentNode: true
            }
            parentTask = newParentTask
          } else if (this.newTask.parentId && this.newTask.parentId !== null) {
            // 查找现有父级任务
            const findTask = (tasks, id) => {
              for (const task of tasks) {
                if (task.id === id) return task
                if (task.children) {
                  const found = findTask(task.children, id)
                  if (found) return found
                }
              }
              return null
            }
            parentTask = findTask(this.ganttData, this.newTask.parentId)
          }

          // 如果是同级任务，需要计算插入位置
          if (this.dialogMode === 'add-sibling' && this.siblingSourceTask) {
            insertPosition = this.findSiblingInsertPosition(this.siblingSourceTask)
          }

          // 创建新任务对象
          const newTask = {
            id: taskId,
            name: this.newTask.name.trim(),
            startDate: this.newTask.startDate,
            endDate: this.newTask.endDate,
            planStartDate: this.newTask.planStartDate || null,
            planEndDate: this.newTask.planEndDate || null,
            progress: parseInt(this.newTask.progress) || 0,
            priority: this.newTask.priority || 'medium',
            color: this.newTask.color,
            description: this.newTask.description || '',
            level: parentTask ? 1 : 0,
            children: [],
            parentId: parentTask ? parentTask.id : null
          }

          // 添加到store
          const taskData = {
            task: newTask,
            parentTask,
            newParentTask,
            insertPosition // 同级任务的插入位置
          }

          await this.$store.dispatch('addTaskWithParent', taskData)

          this.showAddDialog = false
          this.resetTaskForm()

          // 根据模式显示不同的成功消息
          const successMessage = this.dialogMode === 'add-sibling'
            ? `同级任务 "${newTask.name}" 添加成功!`
            : this.dialogMode === 'add-child'
              ? `子任务 "${newTask.name}" 添加成功!`
              : `任务 "${newTask.name}" 添加成功!`

          this.$message.success(successMessage)
          this.autoRangeDebounced() // 新增后自动 range
        } catch (error) {
          this.$message.error('添加任务失败，请重试。')
        } finally {
          this.addingTask = false
        }
      })
    },

    // 更新现有任务
    async updateExistingTask() {
      try {
        // 查找当前任务以获取原始父任务信息
        const originalTask = this.findTaskById(this.editingTaskId)
        if (!originalTask) {
          throw new Error('找不到要编辑的任务')
        }

        // 构建更新数据
        const updates = {
          name: this.newTask.name.trim(),
          startDate: this.newTask.startDate,
          endDate: this.newTask.endDate,
          planStartDate: this.newTask.planStartDate || null,
          planEndDate: this.newTask.planEndDate || null,
          progress: parseInt(this.newTask.progress) || 0,
          priority: this.newTask.priority || 'medium',
          color: this.newTask.color,
          description: this.newTask.description || '',
          parentId: this.newTask.parentId
        }

        // 检查是否需要处理父任务变更
        const parentChanged = originalTask.parentId !== this.newTask.parentId

        if (parentChanged) {
          // 如果父任务发生变化，需要重新组织任务结构
          this.$store.dispatch('moveTaskToNewParent', {
            taskId: this.editingTaskId,
            newParentId: this.newTask.parentId,
            updates
          })
        } else {
          // 如果父任务没有变化，直接更新任务信息
          this.$store.commit('UPDATE_GANTT_ITEM', {
            id: this.editingTaskId,
            updates
          })
        }

        this.showAddDialog = false
        this.resetTaskForm()
        this.$message.success(`任务 "${updates.name}" 更新成功!`)
        this.autoRangeDebounced() // 更新后自动 range
      } catch (error) {
        console.error('更新任务失败:', error)
        this.$message.error('更新任务失败，请重试。')
        throw error
      }
    },

    // 重置任务表单
    resetTaskForm() {
      // 重置对话框模式和相关状态
      this.dialogMode = 'add'
      this.editingTaskId = null
      this.siblingSourceTask = null
      this.childSourceTask = null

      // 重置表单数据
      this.newTask = {
        name: '',
        parentId: null,
        newParentName: '',
        startDate: '',
        endDate: '',
        planStartDate: '',
        planEndDate: '',
        progress: 0,
        priority: 'medium',
        color: '#3498db',
        description: ''
      }

      // 重置表单验证状态
      if (this.$refs.addTaskForm) {
        this.$refs.addTaskForm.resetFields()
        this.$refs.addTaskForm.clearValidate()
      }
    },

    // 查找同级任务的插入位置
    findSiblingInsertPosition(sourceTask) {
      // 查找源任务在其父级中的位置
      if (!sourceTask.parentId) {
        // 如果源任务是根级任务，在根级数组中查找位置
        const rootIndex = this.ganttData.findIndex(group => {
          return group.children && group.children.some(child => child.id === sourceTask.id)
        })
        if (rootIndex !== -1) {
          const group = this.ganttData[rootIndex]
          const childIndex = group.children.findIndex(child => child.id === sourceTask.id)
          return {
            parentGroup: group,
            insertIndex: childIndex + 1 // 插入到源任务后面
          }
        }
      } else {
        // 查找父级任务并确定插入位置
        const findParentAndIndex = (tasks, parentId, taskId) => {
          for (const task of tasks) {
            if (task.id === parentId && task.children) {
              const index = task.children.findIndex(child => child.id === taskId)
              if (index !== -1) {
                return {
                  parentTask: task,
                  insertIndex: index + 1
                }
              }
            }
            if (task.children) {
              const result = findParentAndIndex(task.children, parentId, taskId)
              if (result) return result
            }
          }
          return null
        }

        return findParentAndIndex(this.ganttData, sourceTask.parentId, sourceTask.id)
      }
      return null
    },

    // 根据ID查找任务
    findTaskById(taskId) {
      const findInTasks = (tasks, id) => {
        for (const task of tasks) {
          if (task.id === id) return task
          if (task.children) {
            const found = findInTasks(task.children, id)
            if (found) return found
          }
        }
        return null
      }
      return findInTasks(this.ganttData, taskId)
    },

    // 验证日期范围
    validateDateRange() {
      if (this.newTask.startDate && this.newTask.endDate) {
        if (moment(this.newTask.startDate).isAfter(moment(this.newTask.endDate))) {
          this.$message.warning('Start date cannot be after end date!')
          // 自动调整结束日期
          this.newTask.endDate = this.newTask.startDate
        }
      }
      // 验证表单字段
      if (this.$refs.addTaskForm) {
        this.$refs.addTaskForm.validateField('startDate')
        this.$refs.addTaskForm.validateField('endDate')
      }
    },

    // 验证计划日期范围
    validatePlanDateRange() {
      if (this.newTask.planStartDate && this.newTask.planEndDate) {
        if (moment(this.newTask.planStartDate).isAfter(moment(this.newTask.planEndDate))) {
          this.$message.warning('Plan start date cannot be after plan end date!')
          // 自动调整计划结束日期
          this.newTask.planEndDate = this.newTask.planStartDate
        }
      }
    },

    // 处理表格挂载
    handleTableMounted(tableInstance) {
      this.tableInstance = tableInstance
    },

    // 处理表格滚动 - 同步到右侧甘特图
    handleTableScroll(event) {
      // 如果正在拖拽甘特图，不处理表格滚动同步
      if (this.isDragging) return

      const {scrollTop} = event.target
      const {scrollLeft} = event.target // CustomGanttTable 也可能处理水平滚动

      // 防止滚动循环同步
      if (this.scrollSyncLock) return
      this.scrollSyncLock = true

      // 表格滚动同步

      // 同步垂直滚动到右侧甘特图
      const rightScrollContainer = this.$refs.scrollContainer
      if (rightScrollContainer && Math.abs(rightScrollContainer.scrollTop - scrollTop) > 1) {
        rightScrollContainer.scrollTop = scrollTop
      }

      // 使用nextTick确保DOM更新完成后释放锁
      this.$nextTick(() => {
        this.scrollSyncLock = false
      })
    },

    // 处理虚拟表格滚动
    handleVirtualTableScroll({ scrollTop }) {
      // 如果正在拖拽甘特图，不处理虚拟表格滚动同步
      if (this.isDragging) return

      // 防止滚动循环同步
      if (this.scrollSyncLock) return
      this.scrollSyncLock = true

      // 同步右侧甘特图的垂直滚动位置
      const rightScrollContainer = this.$refs.scrollContainer
      if (rightScrollContainer && Math.abs(rightScrollContainer.scrollTop - scrollTop) > 1) {
        rightScrollContainer.scrollTop = scrollTop
      }

      // 使用nextTick确保DOM更新完成后释放锁
      this.$nextTick(() => {
        this.scrollSyncLock = false
      })
    },

    // 处理列重新排序
    handleColumnReorder() {
      // 列重新排序后的处理
      this.$forceUpdate()
    },

    // 处理视图模式变化
    handleViewModeChange(newMode) {
      console.log('[调试] handleViewModeChange 被调用，模式:', newMode)

      // 向父组件发送视图模式变化事件
      this.$emit('view-mode-change', newMode)

      // 如果没有手动设置日期范围，视图模式改变时可能需要重新计算日期范围
      if (!this.isManualDateRange) {
        this.$forceUpdate()
      }

      // 重新计算每天的宽度和总宽度
      this.$nextTick(() => {
        // 先更新容器宽度，确保后续计算正确
        this.updateRightAreaWidth()

        // 直接调用重绘方法
        this.handleResize()

        // 强制重新计算依赖线
        if (this.$refs.ganttBars) {
          this.$refs.ganttBars.clearDependencyCache()
          this.$refs.ganttBars.$forceUpdate()
        }

        // 再次更新宽度，确保所有计算都基于新的视图模式
        this.$nextTick(() => {
          this.updateRightAreaWidth()

          // 更新时间轴
          if (this.$refs.timeline) {
            this.$refs.timeline.$forceUpdate()
          }

          console.log('[视图模式切换] 已完成视图更新，当前模式:', newMode, '宽度:', this.rightAreaWidth)
        })
      })
    },

    // 跳转到今天
    jumpToToday() {
      this.$store.dispatch('jumpToToday')

      // 计算今天的位置并滚动到今天
      this.$nextTick(() => {
        const today = moment()

        // 如果今天不在当前日期范围内，先调整日期范围
        if (!today.isBetween(this.chartStartDate, this.chartEndDate, 'day', '[]')) {
          // 自动调整日期范围以包含今天
          const newStart = today.clone().subtract(15, 'days')
          const newEnd = today.clone().add(45, 'days')

          this.dateRange = [newStart.format('YYYY-MM-DD'), newEnd.format('YYYY-MM-DD')]

          // 等待日期范围更新后再滚动
          this.$nextTick(() => {
            setTimeout(() => {
              this.scrollToToday()
            }, 100) // 给一点时间让组件重新渲染
          })
        } else {
          this.scrollToToday()
        }

        // 显示成功提示
        this.$message({
          message: 'Jumped to today!',
          type: 'success',
          duration: 2000
        })
      })
    },

    // 滚动到今天的位置
    scrollToToday() {
      const today = moment()
      const daysDiff = today.diff(this.chartStartDate, 'days')
      const dayWidth = this.getDayWidth()
      const scrollLeft = daysDiff * dayWidth

      if (this.$refs.scrollContainer) {
        const container = this.$refs.scrollContainer
        // 滚动到今天位置，并居中显示
        const targetScrollLeft = Math.max(0, scrollLeft - container.clientWidth / 2)

        // 使用scrollTo进行平滑滚动
        container.scrollTo({
          left: targetScrollLeft,
          behavior: 'smooth'
        })

        // 如果浏览器不支持smooth，使用直接设置
        setTimeout(() => {
          if (container.scrollLeft !== targetScrollLeft) {
            container.scrollLeft = targetScrollLeft
          }
        }, 100)
      }
    },

    // 清除血缘关系高亮
    clearLineageHighlight() {
      this.$store.dispatch('clearLineageHighlight')
      this.$message({
        message: 'Highlight cleared',
        type: 'info',
        duration: 1500
      })
    },

    // 计算每日宽度 - 与其他组件保持一致
    getDayWidth() {
      // 确保容器宽度有效
      const availableWidth = Math.max(this.rightAreaWidth, 800)
      const totalDays = this.chartEndDate.diff(this.chartStartDate, 'days') + 1

      // 根据视图模式设置合适的单位宽度
      let baseWidth
      switch(this.effectiveViewMode) {
      case 'day':
        // 日视图：每天至少40px，最多80px
        baseWidth = Math.min(Math.max(availableWidth / totalDays, 40), 80)
        break
      case 'week':
        // 周视图：每天至少15px，最多30px
        baseWidth = Math.min(Math.max(availableWidth / totalDays, 15), 30)
        break
      case 'month':
        // 月视图：每天至少3px，最多20px
        baseWidth = Math.min(Math.max(availableWidth / totalDays, 3), 20)
        break
      case 'quarter':
        // 季度视图：每天至少2px，最多10px
        baseWidth = Math.min(Math.max(availableWidth / totalDays, 2), 10)
        break
      case 'year':
        // 年视图：每天至少1px，最多5px
        baseWidth = Math.min(Math.max(availableWidth / totalDays, 1), 5)
        break
      default:
        baseWidth = Math.max(availableWidth / totalDays, 3)
      }

      console.log(`[天宽度计算] 视图模式: ${this.effectiveViewMode}, 可用宽度: ${availableWidth}px, 总天数: ${totalDays}, 每天宽度: ${baseWidth}px`)
      return baseWidth
    },

    // 处理任务点击（血缘关系高亮）
    handleTaskClick(taskId) {
      this.$store.dispatch('setLineageHighlight', taskId)
    },

    // 初始化性能监控
    initPerformanceMonitoring() {
      if (!this.performanceMonitorEnabled) return

      // 开始帧率监控
      this.startFrameRateMonitoring()

      // 定期检查性能
      this.performanceCheckTimer = setInterval(() => {
        this.checkPerformanceAndOptimize()
      }, this.autoOptimizeConfig.performanceCheckInterval)
    },

    // 清理性能监控
    cleanupPerformanceMonitoring() {
      if (this.performanceCheckTimer) {
        clearInterval(this.performanceCheckTimer)
      }
      if (this.frameRateAnimationId) {
        cancelAnimationFrame(this.frameRateAnimationId)
      }
    },

    // 开始帧率监控
    startFrameRateMonitoring() {
      let frameCount = 0
      let lastTime = performance.now()

      const countFrames = (currentTime) => {
        frameCount++

        if (currentTime - lastTime >= 1000) {
          this.performanceMetrics.frameCount = frameCount
          frameCount = 0
          lastTime = currentTime
        }

        this.frameRateAnimationId = requestAnimationFrame(countFrames)
      }

      this.frameRateAnimationId = requestAnimationFrame(countFrames)
    },

    // 检查自动优化
    checkAutoOptimization() {
      // 根据任务数量自动启用虚拟滚动
      if (this.flattenTasks.length > this.autoOptimizeConfig.maxTasksBeforeVirtual) {
        this.useVirtualScrolling = true
        this.$message({
          message: `Virtual scrolling auto-enabled for ${this.flattenTasks.length} tasks`,
          type: 'info',
          duration: 3000
        })
      }
    },

    // 开始性能监控
    startPerformanceMonitoring() {
      if (this.performanceTimer) {
        clearInterval(this.performanceTimer)
      }

      this.performanceTimer = setInterval(() => {
        this.checkPerformanceAndOptimize()
      }, this.autoOptimizeConfig.performanceCheckInterval)
    },

    // 停止性能监控
    stopPerformanceMonitoring() {
      if (this.performanceTimer) {
        clearInterval(this.performanceTimer)
        this.performanceTimer = null
      }
    },

    // 性能检查和优化
    checkPerformanceAndOptimize() {
      if (!this.autoOptimizeConfig.enabled) return

      const avgRenderTime = this.performanceMetrics.averageRenderTime
      const taskCount = this.flattenTasks.length

      // 如果渲染时间过长，自动启用虚拟滚动
      if (avgRenderTime > this.autoOptimizeConfig.maxRenderTime && !this.useVirtualScrolling) {
        this.useVirtualScrolling = true

        this.$message({
          message: `Virtual scrolling auto-enabled due to slow rendering (${Math.round(avgRenderTime)}ms avg)`,
          type: 'warning',
          duration: 4000
        })
      }
    },

    // 记录渲染时间
    recordRenderTime() {
      if (this.renderStartTime > 0) {
        const renderTime = performance.now() - this.renderStartTime
        this.currentRenderTime = Math.round(renderTime)

        // 更新平均渲染时间
        this.performanceMetrics.renderTimes.push(renderTime)
        if (this.performanceMetrics.renderTimes.length > 20) {
          this.performanceMetrics.renderTimes.shift()
        }

        this.performanceMetrics.averageRenderTime =
          this.performanceMetrics.renderTimes.reduce((a, b) => a + b, 0) /
          this.performanceMetrics.renderTimes.length
      }
    },

    // 开始渲染计时
    startRenderTiming() {
      this.renderStartTime = performance.now()
    },

    // 处理虚拟表格排序
    handleVirtualTableSort(sortInfo) {
      // 实现排序逻辑
      const { column, direction } = sortInfo

      this.flatTableData.sort((a, b) => {
        let aVal = this.getColumnValue(a, column)
        let bVal = this.getColumnValue(b, column)

        // 处理不同数据类型的排序
        if (column.includes('Date')) {
          aVal = new Date(aVal).getTime()
          bVal = new Date(bVal).getTime()
        } else if (typeof aVal === 'string') {
          aVal = aVal.toLowerCase()
          bVal = bVal.toLowerCase()
        }

        if (direction === 'asc') {
          return aVal > bVal ? 1 : -1
        } else {
          return aVal < bVal ? 1 : -1
        }
      })
    },

    // 获取列值（用于排序）
    getColumnValue(item, key) {
      return key.split('.').reduce((obj, k) => obj && obj[k], item)
    },

    // 处理性能监控自动优化切换
    handleAutoOptimizeToggle(enabled) {
      this.autoOptimizeConfig.enabled = enabled

      if (enabled) {
        this.checkAutoOptimization()
        this.startPerformanceMonitoring()
        this.$message({
          message: `Auto Optimization enabled. Monitoring ${this.flattenTasks.length} tasks for performance.`,
          type: 'success',
          duration: 3000
        })
      } else {
        this.stopPerformanceMonitoring()
        this.$message({
          message: 'Auto Optimization disabled',
          type: 'info',
          duration: 2000
        })
      }
    },

    // 切换虚拟滚动
    toggleVirtualScrolling() {
      this.useVirtualScrolling = !this.useVirtualScrolling

      this.$message({
        message: `Virtual scrolling ${this.useVirtualScrolling ? 'enabled' : 'disabled'}`,
        type: 'success',
        duration: 2000
      })
    },

    // 切换性能监控
    togglePerformanceMonitor() {
      this.performanceMonitorEnabled = !this.performanceMonitorEnabled
    },

    // 导出性能数据
    exportPerformanceData() {
      const data = {
        timestamp: new Date().toISOString(),
        taskCount: this.flattenTasks.length,
        visibleTaskCount: this.visibleTaskCount,
        renderTime: this.currentRenderTime,
        metrics: this.performanceMetrics,
        config: {
          virtualScrolling: this.useVirtualScrolling,
          autoOptimize: this.autoOptimizeConfig
        }
      }

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `gantt-performance-${Date.now()}.json`
      a.click()
      URL.revokeObjectURL(url)
    },

    // 优化大数据渲染
    optimizeForLargeData() {
      const taskCount = this.flattenTasks.length

      if (taskCount > 1000) {
        // 启用虚拟滚动
        this.useVirtualScrolling = true

        // 调整缓冲区大小
        this.virtualScrollConfig.bufferSize = Math.min(10, Math.ceil(taskCount / 100))

        // 降低更新频率
        this.performanceCheckInterval = 10000

        // 大数据集优化完成
      }
    },

    // 重置性能优化设置
    resetPerformanceSettings() {
      this.useVirtualScrolling = false
      this.autoOptimizeConfig.enabled = false
      this.performanceMetrics = {
        frameCount: 0,
        lastFrameTime: 0,
        averageRenderTime: 0,
        renderTimes: []
      }

      this.$message({
        message: 'Performance settings reset to default',
        type: 'info',
        duration: 2000
      })
    },

    // 更新表格高度
    updateTableHeight() {
      if (this.$refs.customTable && this.$refs.customTable.updateTableHeight) {
        this.$refs.customTable.updateTableHeight()
      }
    },

    // 生成测试数据
    async generateTestData(command) {
      try {
        if (command === 'clear') {
          this.$store.commit('SET_GANTT_DATA', [])
          this.$store.commit('SET_COLLAPSED_TASKS', []) // 清空折叠，全部展开
          this.$message.success('All data cleared!')
          this.$nextTick(() => {
            this.updateRightAreaWidth()
            this.$forceUpdate()
          })
          return
        }

        const count = parseInt(command)
        this.$message.info(`Generating ${count} tasks...`)

        const result = await this.$store.dispatch('generateLargeDataset', count)

        // 如果生成的任务数量超过阈值，自动启用虚拟滚动
        if (count >= 500) {
          this.useVirtualScrolling = true
          this.$store.commit('SET_COLLAPSED_TASKS', []) // 清空折叠，全部展开
          this.$message.success(`Generated ${result.totalTasks} tasks! Virtual scrolling enabled automatically.`)
        } else {
          this.$store.commit('SET_COLLAPSED_TASKS', []) // 清空折叠，全部展开
          this.$message.success(`Generated ${result.totalTasks} tasks!`)
        }

        // 测试数据生成完成
        this.$nextTick(() => {
          this.updateRightAreaWidth()
          this.$forceUpdate()
        })
        this.autoRangeDebounced()
      } catch (error) {
        this.$message.error('Failed to generate test data')
      }
    },

    // 处理任务聚焦
    handleFocusTask(task) {

      // 高亮任务
      this.highlightedRowId = task.id

      // 滚动到任务位置（在表格中）
      this.$nextTick(() => {
        // 如果使用虚拟滚动
        if (this.shouldUseVirtualScrolling && this.$refs.virtualTable) {
          const taskIndex = this.flatTableDataForVirtual.findIndex(item => item.id === task.id)
          if (taskIndex >= 0) {
            const scrollTop = taskIndex * this.virtualScrollConfig.itemHeight
            if (this.$refs.virtualTable.scrollToPosition) {
              this.$refs.virtualTable.scrollToPosition(scrollTop)
            }
          }
        }
        // 如果使用普通表格
        else if (this.$refs.customTable) {
          const taskIndex = this.flatTableData.findIndex(item => item.id === task.id)
          if (taskIndex >= 0) {
            // 检查scrollToRow方法是否存在
            if (typeof this.$refs.customTable.scrollToRow === 'function') {
              this.$refs.customTable.scrollToRow(taskIndex)
            } else {
              // 如果方法不存在，使用基础的scrollTo方法
              const rowTop = taskIndex * 40 // 每行40px高度
              if (typeof this.$refs.customTable.scrollTo === 'function') {
                this.$refs.customTable.scrollTo(rowTop)
              }
            }
          }
        }
      })

      // 触发高亮效果
      this.handleTaskHighlight(task.id)
    },

    // 初始化日期范围
    initializeDateRange() {
      // 基于现有任务数据计算合适的日期范围
      if (!this.flattenTasks || this.flattenTasks.length === 0) {
        // 如果没有任务，设置默认日期范围（从今天开始的3个月）
        const today = moment()
        const startDate = today.clone().subtract(1, 'month')
        const endDate = today.clone().add(2, 'months')

        this.dateRange = [
          startDate.format('YYYY-MM-DD'),
          endDate.format('YYYY-MM-DD')
        ]

        return
      }

      // 找到所有任务的最早和最晚日期
      let minDate = null
      let maxDate = null

      this.flattenTasks.forEach(task => {
        // 检查开始日期
        if (task.startDate) {
          const startDate = moment(task.startDate)
          if (!minDate || startDate.isBefore(minDate)) {
            minDate = startDate
          }
        }

        // 检查结束日期
        if (task.endDate) {
          const endDate = moment(task.endDate)
          if (!maxDate || endDate.isAfter(maxDate)) {
            maxDate = endDate
          }
        }

        // 检查计划日期
        if (task.planStartDate) {
          const planStartDate = moment(task.planStartDate)
          if (!minDate || planStartDate.isBefore(minDate)) {
            minDate = planStartDate
          }
        }

        if (task.planEndDate) {
          const planEndDate = moment(task.planEndDate)
          if (!maxDate || planEndDate.isAfter(maxDate)) {
            maxDate = planEndDate
          }
        }
      })

      // 如果没有找到有效日期，使用默认范围
      if (!minDate || !maxDate) {
        const today = moment()
        minDate = today.clone().subtract(1, 'month')
        maxDate = today.clone().add(2, 'months')
      }

      // 添加缓冲时间，让视图更宽松
      const timeSpan = maxDate.diff(minDate, 'days')
      let bufferDays = 15 // 默认缓冲15天

      // 根据项目时间跨度调整缓冲时间
      if (timeSpan <= 30) {
        bufferDays = 7   // 短项目：7天缓冲
      } else if (timeSpan <= 90) {
        bufferDays = 15  // 中期项目：15天缓冲
      } else if (timeSpan <= 365) {
        bufferDays = 30  // 长期项目：30天缓冲
      } else {
        bufferDays = 60  // 超长项目：60天缓冲
      }

      const adjustedStartDate = minDate.clone().subtract(bufferDays, 'days')
      const adjustedEndDate = maxDate.clone().add(bufferDays, 'days')

      // 设置计算出的日期范围
      this.dateRange = [
        adjustedStartDate.format('YYYY-MM-DD'),
        adjustedEndDate.format('YYYY-MM-DD')
      ]

      // 根据时间跨度自动设置合适的视图模式
      const totalDays = adjustedEndDate.diff(adjustedStartDate, 'days')
      const months = adjustedEndDate.diff(adjustedStartDate, 'months')
      const years = adjustedEndDate.diff(adjustedStartDate, 'years')

      if (years >= 2) {
        this.$emit('update:currentViewMode', 'year')
      } else if (months >= 6) {
        this.$emit('update:currentViewMode', 'month')
      } else if (totalDays > 60) {
        this.$emit('update:currentViewMode', 'month')
      } else {
        this.$emit('update:currentViewMode', 'day')
      }

      // 日期范围已自动初始化

      // 显示友好的提示信息
      this.$message({
        message: `Date range auto-set based on ${this.flattenTasks.length} tasks (${adjustedStartDate.format('MMM DD')} ~ ${adjustedEndDate.format('MMM DD, YYYY')})`,
        type: 'success',
        duration: 3000
      })
      this.$nextTick(() => {
        // 强制刷新 dateRange 绑定，确保 el-date-picker 选择框能动态更新
        this.dateRange = [...this.dateRange]
      })
    },
    updateLeftPanelHeight() {
      this.$nextTick(() => {
        // 确保ganttMain容器已正确渲染
        if (this.$refs.ganttMain && this.$refs.ganttMain.clientHeight > 0) {
          const left = this.$refs.ganttMain.querySelector('.gantt-left')
          if (left && left.clientHeight > 0) {
            // 使用与tableHeight相同的计算逻辑，确保一致性
            const mainHeight = this.$refs.ganttMain.clientHeight
            const headerHeight = 64
            this.leftPanelHeight = Math.max(mainHeight - headerHeight, 400)
          }
        }
      })
    },
    autoRangeDebounced: debounce(function() {
      this.initializeDateRange()
      this.$nextTick(() => {
        // 强制刷新 dateRange 绑定，确保 el-date-picker 选择框能动态更新
        this.dateRange = [...this.dateRange]
      })
    }, 200),

    // Timeline 相关方法
    handleMilestoneSelected(milestone) {
      // 跳转到里程碑日期的逻辑
      if (milestone.startDate) {
        const milestoneDate = moment(milestone.startDate)
        // 这里可以添加滚动到对应日期的逻辑
        this.$message({
          message: `Milestone selected: ${milestone.name}`,
          type: 'info',
          duration: 2000
        })
      }
    },

    handleTimelineHidden() {
      // 时间轴概览被隐藏的处理逻辑
      this.$emit('timeline-hidden')
    },

    // 增强Today按钮功能，同时控制timeline
    jumpToTodayEnhanced() {
      // 调用原有的jumpToToday方法
      this.jumpToToday()

      // 同时让timeline也跳转到今天
      if (this.$refs.ganttOverviewTimeline) {
        this.$refs.ganttOverviewTimeline.scrollToToday()
      }
    },

    // 切换连接线灰色模式
    toggleGrayConnectionMode() {
      this.$store.dispatch('toggleGrayConnectionMode')
      this.$message({
        message: `连接线已切换为${this.grayConnectionMode ? '彩色' : '灰色'}模式`,
        type: 'info',
        duration: 2000
      })
    }
  },
  mounted() {
    // 初始化
    this.$emit('update:currentViewMode', this.$store.state.viewMode || 'month')

    // 自动初始化日期范围
    this.$nextTick(() => {
      this.initializeDateRange()
    })

    // 监听右侧区域宽度变化
    this.$nextTick(() => {
      // 初始更新一次宽度
      this.updateRightAreaWidth()

      if (this.$refs.ganttRight && window.ResizeObserver) {
        this.resizeObserver = new ResizeObserver(() => {
          // 延迟一下，确保所有布局都稳定
          setTimeout(() => {
            this.updateRightAreaWidth()
            // 同时更新表格高度
            this.updateTableHeight()
          }, 50)
        })
        this.resizeObserver.observe(this.$refs.ganttRight)
      }

      // 再次延迟更新，确保在组件挂载后立即获得正确的宽度
      setTimeout(() => {
        this.updateRightAreaWidth()
        this.updateTableHeight()
      }, 100)
    })

    this.initPerformanceMonitoring()
    this.checkAutoOptimization()
    this.updateRightAreaWidth()
    window.addEventListener('resize', this.updateRightAreaWidth)
    this.updateLeftPanelHeight()
    window.addEventListener('resize', this.updateLeftPanelHeight)
    this.$nextTick(() => {
      this.updateTableHeight()
      window.addEventListener('resize', this.updateTableHeight)
    })
  },
  updated() {
    // 在组件更新后也检查一下高度
    this.$nextTick(() => {
      this.updateTableHeight()
    })
  },
  beforeDestroy() {
    // 清理事件监听器
    if (this.sortableInstance) {
      this.sortableInstance.destroy()
    }
    if (this.columnSortableInstance) {
      this.columnSortableInstance.destroy()
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect()
    }

    // 清理拖拽状态
    if (this.isDragging) {
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }

    // 清理父节点拖拽防抖定时器
    if (this.parentDragDebounceTimer) {
      clearTimeout(this.parentDragDebounceTimer)
      this.parentDragDebounceTimer = null
    }

    this.cleanupPerformanceMonitoring()
    this.stopPerformanceMonitoring()
    window.removeEventListener('resize', this.updateRightAreaWidth)
    window.removeEventListener('resize', this.updateLeftPanelHeight)
    window.removeEventListener('resize', this.updateTableHeight)
  },
  // 监听数据变化，及时进行性能优化
  watch: {
    flattenTasks() {
      this.updateRightAreaWidth()
    },
    chartStartDate() {
      this.updateRightAreaWidth()
    },
    chartEndDate() {
      this.updateRightAreaWidth()
    },
    dateRange() {
      this.updateRightAreaWidth()
    },
    ganttData: {
      handler() {
        this.updateRightAreaWidth()
      },
      deep: true
    }
  }
}
</script>

<style scoped>
.gantt-chart {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #f8fafc;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
}

/* gantt-controls已移除，设置功能已迁移到Performance Monitor */

.operation-tips {
  display: flex;
  align-items: center;
  gap: 20px;
  color: rgba(255, 255, 255, 0.9);
}

.tip-text {
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
}

.view-mode-selector {
  display: flex;
  align-items: center;
  gap: 10px;
}

.view-mode-selector label {
  font-size: 14px;
  font-weight: 600;
  color: #ffffff;
}

.tooltip-controls,
.gantt-display-controls {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  margin-left: 20px;
  gap: 10px;
  max-width: 650px;
}

.tooltip-controls label,
.gantt-display-controls label {
  display: flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  font-size: 13px;
}

.tooltip-checkbox {
  margin-right: 8px;
  cursor: pointer;
  transform: scale(1.2);
}

.tooltip-label {
  font-size: 14px;
  font-weight: 600;
  color: #ffffff;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

.view-mode-select {
  padding: 6px 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
  font-size: 14px;
  min-width: 120px;
  backdrop-filter: blur(5px);
  transition: all 0.3s ease;
}

.view-mode-select:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.5);
  background: rgba(255, 255, 255, 0.25);
}

/* 移除 .gantt-actions 样式，使用 .quick-actions */

.btn {
  padding: 10px 16px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 8px;
  text-decoration: none;
  position: relative;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
}

.btn:hover {
  background: rgba(255, 255, 255, 0.25);
  border-color: rgba(255, 255, 255, 0.4);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.btn:active {
  transform: translateY(0);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.btn-primary {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  color: #ffffff;
  border: none;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #43a3f4 0%, #00e6f0 100%);
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(79, 172, 254, 0.4);
}

.btn-secondary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #ffffff;
  border: none;
}

.btn-secondary:hover {
  background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.btn-today {
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
  color: #ffffff;
  border: none;
}

.btn-today:hover {
  background: linear-gradient(135deg, #f8638a 0%, #fdd835 100%);
  box-shadow: 0 6px 20px rgba(250, 112, 154, 0.4);
}

.btn-highlight {
  background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
  color: #4a5568;
  border: none;
}

.btn-reset {
  background: rgba(255, 255, 255, 0.2);
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 8px;
  border-radius: 6px;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-reset:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: rotate(180deg);
}

.btn-icon {
  font-size: 16px;
}

.gantt-main {
  display: flex;
  height: 100%;
  min-height: 0;
  border-top:1px solid #ddd;
}

.gantt-left {
  height: 100%;
  min-height: 0;
}

.gantt-right {
  height: 100%;
  min-height: 0;
  overflow-x: visible;
  overflow-y: hidden;
}

.gantt-splitter {
  width: 8px;
  background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
  cursor: col-resize;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: background 0.3s ease;
}

.gantt-splitter:hover {
  background: linear-gradient(135deg, #cbd5e0 0%, #a0aec0 100%);
}

.toggle-panel-btn {
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid #e2e8f0;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.toggle-panel-btn:hover {
  background: #ffffff;
  border-color: #cbd5e0;
  transform: scale(1.1);
}

.show-panel-btn {
  position: absolute;
  left: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #ffffff;
  border: none;
  border-radius: 8px;
  width: 32px;
  height: 48px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.show-panel-btn:hover {
  background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
  transform: translateY(-50%) translateX(4px);
}

.gantt-scroll-container {
  height: 100%;
  overflow-x: visible;
  overflow-y: auto;
  scroll-behavior: smooth;
  cursor: grab;
}

.gantt-scroll-container:active {
  cursor: grabbing;
}

.gantt-scroll-container.dragging {
  cursor: grabbing;
  user-select: none;
}

.gantt-scroll-container::-webkit-scrollbar {
  width: 12px;
  height: 12px;
}

.gantt-scroll-container::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 6px;
}

.gantt-scroll-container::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #cbd5e0 0%, #a0aec0 100%);
  border-radius: 6px;
  border: 2px solid #f1f5f9;
}

.gantt-scroll-container::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #a0aec0 0%, #718096 100%);
}

.gantt-timeline-wrapper {
  position: sticky;
  top: 0;
  z-index: 50;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  border-bottom: 2px solid #e2e8f0;
}

.gantt-chart-area {
  position: relative;
  background: #ffffff;
  /* 使用动态计算的高度，避免不必要的空白区域 */
  height: auto;
  min-height: 200px;
  /* 确保内容溢出时正确处理，水平方向允许溢出 */
  overflow-x: visible;
  /* 精确控制高度，避免底部空白 */
  box-sizing: border-box;
}

.gantt-content {
  position: relative;
  transition: transform 0.1s ease-out;
  overflow: visible;
}

/* 对话框样式优化 - 修复层级问题，确保模态框在最顶层 */
.el-dialog__wrapper {
  z-index: 10001 !important;
}

.el-dialog {
  border-radius: 12px;
  overflow: hidden;
  z-index: 10002 !important;
}

.el-dialog__header {
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
  color: #ffffff;
  padding: 20px 24px;
}

.el-dialog__title {
  font-size: 18px;
  font-weight: 600;
  color: #ffffff;
}

.el-dialog__body {
  padding: 24px;
  background: #f8fafc;
}



.el-form-item__label {
  font-weight: 600;
  color: #374151;
}

.el-input__inner {
  border-radius: 8px;
  border: 1px solid #d1d5db;
  transition: all 0.3s ease;
}

.el-input__inner:focus {
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.el-select .el-input__inner {
  border-radius: 8px;
}

.el-date-editor .el-input__inner {
  border-radius: 8px;
}

.el-button {
  border-radius: 8px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.el-button--primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
}

.el-button--primary:hover {
  background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.dialog-footer {
  padding: 16px 24px;
  background: #ffffff;
  border-top: 1px solid #e5e7eb;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .gantt-controls {
    flex-direction: column;
    gap: 16px;
    padding: 16px;
  }

  .date-range-controls {
    flex-wrap: wrap;
    gap: 12px;
  }

  .gantt-actions {
    flex-wrap: wrap;
    justify-content: center;
  }

  .btn {
    padding: 8px 12px;
    font-size: 13px;
  }

  .gantt-left {
    min-width: 250px;
  }
}

/* 滚动条样式优化 - 全局应用淡灰色细窄样式 */
.gantt-scroll-container::-webkit-scrollbar,
.custom-gantt-table::-webkit-scrollbar,
.virtual-scroll-table::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

.gantt-scroll-container::-webkit-scrollbar-track,
.custom-gantt-table::-webkit-scrollbar-track,
.virtual-scroll-table::-webkit-scrollbar-track {
  background: #f7f8fa;
  border-radius: 3px;
}

.gantt-scroll-container::-webkit-scrollbar-thumb,
.custom-gantt-table::-webkit-scrollbar-thumb,
.virtual-scroll-table::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 3px;
  border: 1px solid #f7f8fa;
}

.gantt-scroll-container::-webkit-scrollbar-thumb:hover,
.custom-gantt-table::-webkit-scrollbar-thumb:hover,
.virtual-scroll-table::-webkit-scrollbar-thumb:hover {
  background: #9ca3af;
}

/* ElementUI 日期选择器样式优化 */
.date-range-picker .el-input__inner {
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 6px;
  color: #ffffff;
  font-size: 14px;
  transition: all 0.3s ease;
  backdrop-filter: blur(5px);
}

.date-range-picker .el-input__inner:focus {
  border-color: rgba(255, 255, 255, 0.6);
  background: rgba(255, 255, 255, 0.95);
  color: #374151;
  box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.2);
}

.date-range-picker .el-input__inner::placeholder {
  color: rgba(255, 255, 255, 0.7);
}

/* 时间轴包装器背景修复 */
.gantt-timeline-wrapper {
  position: sticky;
  top: 0;
  z-index: 50;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  border-bottom: 2px solid #e2e8f0;
  /* 确保背景完全覆盖 */
  width: 100%;
  min-width: 100%;
}

/* 甘特图内容区域背景修复 */
.gantt-chart-area {
  position: relative;
  background: #ffffff;
  min-height: 600px;
  /* 确保背景完全覆盖 */
  width: 100%;
}

/* gantt-content样式已在上方定义，避免重复 */

/* 表格样式优化 */
.custom-gantt-table {
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

/* 加载动画 */
@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

.loading {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

/* 悬浮效果 */
.hover-lift {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.hover-lift:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}

/* 渐变文字 */
.gradient-text {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-weight: 700;
}

/* 玻璃态效果 */
.glass-effect {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

/* 高亮边框动画 */
@keyframes borderGlow {
  0%, 100% {
    border-color: #667eea;
    box-shadow: 0 0 5px rgba(102, 126, 234, 0.3);
  }
  50% {
    border-color: #764ba2;
    box-shadow: 0 0 20px rgba(118, 75, 162, 0.5);
  }
}

.glow-border {
  animation: borderGlow 2s ease-in-out infinite;
}

.btn.btn-highlight:hover {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
}

/* 性能优化按钮样式 */
.btn.btn-performance {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: #ffffff;
  border: none;
}

.btn.btn-performance:hover {
  background: linear-gradient(135deg, #059669 0%, #047857 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.btn.btn-performance.active {
  background: linear-gradient(135deg, #047857 0%, #065f46 100%);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

.btn.btn-monitor {
  background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
  color: #ffffff;
  border: none;
}

.btn.btn-monitor:hover {
  background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
}

.btn.btn-monitor.active {
  background: linear-gradient(135deg, #6d28d9 0%, #5b21b6 100%);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

.btn.btn-auto-optimize {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: #ffffff;
  border: none;
}

.btn.btn-auto-optimize:hover {
  background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
}

.btn.btn-auto-optimize.active {
  background: linear-gradient(135deg, #b45309 0%, #92400e 100%);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* 虚拟滚动表格自定义样式 */
.task-name-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.collapse-btn {
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border-radius: 2px;
  transition: background-color 0.2s ease;
  user-select: none;
  font-size: 12px;
}

.collapse-btn:hover {
  background: rgba(102, 126, 234, 0.1);
}

.task-name {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.progress-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.progress-bar {
  flex: 1;
  height: 6px;
  background: #f1f5f9;
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #10b981 0%, #059669 100%);
  border-radius: 3px;
  transition: width 0.3s ease;
}

.progress-text {
  font-size: 11px;
  font-weight: 500;
  color: #6b7280;
  min-width: 35px;
  text-align: right;
}

.status-badge {
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.status-badge.status-completed {
  background: rgba(16, 185, 129, 0.1);
  color: #059669;
  border: 1px solid rgba(16, 185, 129, 0.2);
}

.status-badge.status-progress {
  background: rgba(59, 130, 246, 0.1);
  color: #2563eb;
  border: 1px solid rgba(59, 130, 246, 0.2);
}

.status-badge.status-not-started {
  background: rgba(107, 114, 128, 0.1);
  color: #6b7280;
  border: 1px solid rgba(107, 114, 128, 0.2);
}

/* 左侧面板性能监控器样式 */
.left-panel-performance-monitor {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 100;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-top: 1px solid #e2e8f0;
  padding: 8px;
  font-size: 11px;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1);
  display: none;
}

.gantt-left {
  position: relative; /* 确保定位上下文 */
}

/* 测试数据按钮样式 */
.btn.btn-test {
  background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
  color: #ffffff;
  border: none;
}

.btn.btn-test:hover {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);
}

/* highlighted-row-background 统一样式 */
.highlighted-row-background {

  /* 确保高度和位置与表格行一致 */
  height: 40px;
  position: absolute;
  left: 0;
  right: 0;
  z-index: 1;
}

.gantt-chart-area .timeline-row.highlighted {

  height: 40px;
}

.gantt-right .timeline-row:hover {
  background: #f8f9fa;
}

.gantt-right .timeline-row {
  transition: background-color 0.15s ease;
  border-bottom: 1px solid #f0f3f6;
  /* DHTMLX风格：快速过渡和细边框 */
  height: 40px;
  min-height: 40px;
  box-sizing: border-box;
}

/* 显示控制选项 */
.display-controls-group {
  margin-bottom: 20px;
}

.control-label {
  font-weight: 600;
  margin-bottom: 10px;
}

.control-options {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.control-option {
  display: flex;
  align-items: center;
  gap: 5px;
}

.control-option input[type="checkbox"] {
  margin-right: 5px;
}

.btn.btn-gray-connections {
  background: linear-gradient(135deg, #9ca3af 0%, #718096 100%);
  color: #ffffff;
  border: none;
}

.btn.btn-gray-connections:hover {
  background: linear-gradient(135deg, #718096 0%, #5b636e 100%);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(123, 133, 148, 0.3);
}

.btn.btn-gray-connections.active {
  background: linear-gradient(135deg, #5b636e 0%, #474e5d 100%);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* 工具栏样式 */
.gantt-toolbar {
  display: flex;
  align-items: center;
  padding: 8px 16px;
  background: #f8f9fa;
  border-bottom: 1px solid #e1e8ed;
  gap: 8px;
}

.critical-path-btn {
  font-size: 12px;
}

/* 彻底解决弹框中下拉组件被遮挡问题 */
.el-dialog {
  z-index: 3000 !important;
}

.el-dialog__wrapper {
  z-index: 3000 !important;
}

/* Element UI 下拉组件的最高层级 */
.el-select-dropdown {
  z-index: 10000 !important;
}

.el-picker-panel {
  z-index: 10000 !important;
}

.el-color-dropdown {
  z-index: 10000 !important;
}

.el-color-picker__panel {
  z-index: 10000 !important;
}

/* 确保Element UI的popper组件在弹框上方 */
.el-popper {
  z-index: 10000 !important;
}

/* 确保弹框内输入组件本身不会遮挡下拉 */
.el-dialog__body .el-input {
  z-index: auto;
}

.el-dialog__body .el-select {
  z-index: auto;
}

.el-dialog__body .el-date-picker {
  z-index: auto;
}

/* Element UI date picker和select的特殊处理 */
.el-date-picker .el-picker-panel {
  z-index: 10001 !important;
}

.el-select .el-select-dropdown {
  z-index: 10001 !important;
}
</style>
