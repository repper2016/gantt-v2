<template>
  <div class="gantt-timeline" ref="timelineContainer" :style="{ width: timelineWidth + 'px', minWidth: timelineWidth + 'px', overflowX: 'hidden' }">
    <!-- 主时间轴 -->
    <div class="timeline-scale-top" ref="scaleTop" :style="{ width: timelineWidth + 'px', minWidth: timelineWidth + 'px' }">
      <div
        v-for="period in mainPeriods"
        :key="period.key"
        class="scale-item scale-main"
        :style="{ width: period.width + 'px' }"
      >
        {{ period.label }}
      </div>
    </div>

    <!-- 子时间轴 -->
    <div class="timeline-scale-bottom" ref="scaleBottom" :style="{ width: timelineWidth + 'px', minWidth: timelineWidth + 'px' }">
      <div
        v-for="unit in subPeriods"
        :key="unit.key"
        class="scale-item scale-sub"
        :class="{
          'is-today': unit.isToday,
          'is-weekend': unit.isWeekend,
          'is-month-start': unit.isMonthStart
        }"
        :style="{ width: unit.width + 'px' }"
      >
        {{ unit.label }}
      </div>
    </div>

    <!-- 额外的右侧空间，确保时间轴足够宽 -->
    <div class="timeline-extra-space" :style="{ width: '100px', height: '1px' }"></div>
  </div>
</template>

<script>
import moment from 'moment'

export default {
  name: 'GanttTimeline',
  props: {
    viewMode: {
      type: String,
      default: 'month'
    },
    startDate: {
      type: Object,
      required: true
    },
    endDate: {
      type: Object,
      required: true
    },
    zoomLevel: {
      type: Number,
      default: 1
    },
    panOffset: {
      type: Number,
      default: 0
    },
    containerWidth: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      actualWidth: 1200
    }
  },
  computed: {
    // 计算总天数
    totalDays() {
      return this.endDate.diff(this.startDate, 'days') + 1
    },

    // 获取容器可用宽度
    actualContainerWidth() {
      // 优先使用父组件传入的宽度
      if (this.containerWidth && this.containerWidth > 100) {
        return this.containerWidth
      }

      // 使用缓存的宽度
      return this.actualWidth
    },

    // 自适应单位宽度 - 与甘特图保持完全一致的计算逻辑
    unitWidth() {
      // 使用与GanttChart.getDayWidth()完全相同的计算逻辑
      const availableWidth = Math.max(this.actualContainerWidth, 800)

      // 根据视图模式设置合适的单位宽度，保持与甘特图一致
      let baseWidth
      switch(this.viewMode) {
      case 'day':
        // 日视图：每天至少40px，最多80px
        baseWidth = Math.min(Math.max(availableWidth / this.totalDays, 40), 80)
        break
      case 'month':
        // 月视图：每天至少3px，最多20px
        baseWidth = Math.min(Math.max(availableWidth / this.totalDays, 3), 20)
        break
      case 'year':
        // 年视图：每天至少1px，最多5px
        baseWidth = Math.min(Math.max(availableWidth / this.totalDays, 1), 5)
        break
      default:
        baseWidth = Math.max(availableWidth / this.totalDays, 3)
      }

      return baseWidth
    },

    timelineWidth() {
      // 计算实际需要的时间轴宽度，基于完整的数据范围
      const totalWidth = this.totalDays * this.unitWidth
      // 时间轴应该覆盖整个数据范围，确保向右滚动时能看到完整的时间轴
      return totalWidth
    },

    mainPeriods() {
      const periods = []
      const start = moment(this.startDate)
      const end = moment(this.endDate)

      if (this.viewMode === 'year') {
        // 年视图：按年分组
        const current = start.clone().startOf('year')
        while (current.isSameOrBefore(end, 'year')) {
          const yearStart = moment.max(current.clone().startOf('year'), start)
          const yearEnd = moment.min(current.clone().endOf('year'), end)

          const startPosition = this.getDatePosition(yearStart)
          const endPosition = this.getDatePosition(yearEnd.clone().add(1, 'day'))
          const width = endPosition - startPosition

          periods.push({
            key: current.format('YYYY'),
            label: current.format('YYYY'),
            width,
            startDate: yearStart.format('YYYY-MM-DD'),
            endDate: yearEnd.format('YYYY-MM-DD')
          })

          current.add(1, 'year')
        }
      } else if (this.viewMode === 'month') {
        // 月视图：按月分组
        const current = start.clone().startOf('month')
        while (current.isSameOrBefore(end, 'month')) {
          const monthStart = moment.max(current.clone().startOf('month'), start)
          const monthEnd = moment.min(current.clone().endOf('month'), end)

          const startPosition = this.getDatePosition(monthStart)
          const endPosition = this.getDatePosition(monthEnd.clone().add(1, 'day'))
          const width = endPosition - startPosition

          // 根据月份宽度选择合适的标签格式
          let label
          if (width > 80) {
            label = current.format('MMM YYYY') // 完整格式：Jan 2024
          } else if (width > 50) {
            label = current.format('MMM YY') // 短格式：Jan 24
          } else {
            label = current.format('MM/YY') // 最短格式：01/24
          }

          periods.push({
            key: current.format('YYYY-MM'),
            label,
            width,
            startDate: monthStart.format('YYYY-MM-DD'),
            endDate: monthEnd.format('YYYY-MM-DD')
          })

          current.add(1, 'month')
        }
      } else { // day
        // 日视图：按周分组
        const current = start.clone().startOf('week')
        while (current.isSameOrBefore(end, 'week')) {
          const weekStart = moment.max(current.clone().startOf('week'), start)
          const weekEnd = moment.min(current.clone().endOf('week'), end)

          const startPosition = this.getDatePosition(weekStart)
          const endPosition = this.getDatePosition(weekEnd.clone().add(1, 'day'))
          const width = endPosition - startPosition

          // 根据周宽度选择合适的标签格式
          let label
          if (width > 120) {
            label = `${weekStart.format('MMM DD')} - ${weekEnd.format('MMM DD')}` // 完整格式
          } else if (width > 80) {
            label = `${weekStart.format('MM/DD')}-${weekEnd.format('MM/DD')}` // 中等格式
          } else {
            label = `W${current.format('WW')}` // 周数格式：W01
          }

          periods.push({
            key: current.format('YYYY-[W]WW'),
            label,
            width,
            startDate: weekStart.format('YYYY-MM-DD'),
            endDate: weekEnd.format('YYYY-MM-DD')
          })

          current.add(1, 'week')
        }
      }

      return periods
    },

    subPeriods() {
      const periods = []
      const start = moment(this.startDate)
      const end = moment(this.endDate)
      const today = moment().startOf('day')

      if (this.viewMode === 'year') {
        // 年视图：显示月份
        const current = start.clone().startOf('month')
        while (current.isSameOrBefore(end, 'month')) {
          const monthStart = moment.max(current.clone().startOf('month'), start)
          const monthEnd = moment.min(current.clone().endOf('month'), end)

          const startPosition = this.getDatePosition(monthStart)
          const endPosition = this.getDatePosition(monthEnd.clone().add(1, 'day'))
          const width = endPosition - startPosition

          // 根据月份宽度选择合适的标签格式
          let label
          if (width > 40) {
            label = current.format('MMM') // 完整月份名：Jan
          } else if (width > 25) {
            label = current.format('MM') // 月份数字：01
          } else {
            label = current.format('M') // 简短月份：1
          }

          periods.push({
            key: current.format('YYYY-MM'),
            label,
            width,
            isToday: current.isSame(today, 'month'),
            date: current.format('YYYY-MM-DD')
          })

          current.add(1, 'month')
        }
      } else if (this.viewMode === 'month') {
        // 月视图：显示日期 - 修复重叠问题和1号标记
        const current = start.clone()
        while (current.isSameOrBefore(end, 'day')) {
          const isWeekend = current.day() === 0 || current.day() === 6
          const dayOfMonth = current.date()
          const isMonthStart = dayOfMonth === 1 // 修复：正确判断每月1号

          // 修复标签显示逻辑，避免重叠
          let label = ''

          if (this.unitWidth >= 25) {
            // 宽度足够时显示完整日期
            label = current.format('DD')
          } else if (this.unitWidth >= 15) {
            // 中等宽度时显示简短日期
            label = current.format('D')
          } else if (this.unitWidth >= 8) {
            // 较小宽度时只显示特定日期
            if (dayOfMonth === 1 || dayOfMonth === 15 || dayOfMonth % 10 === 0) {
              label = current.format('D')
            }
          } else {
            // 最小宽度时只显示月初
            if (dayOfMonth === 1) {
              label = current.format('M/D')
            }
          }

          periods.push({
            key: current.format('YYYY-MM-DD'),
            label,
            width: this.unitWidth,
            isToday: current.isSame(today, 'day'),
            isWeekend,
            isMonthStart, // 添加月初标记
            date: current.format('YYYY-MM-DD'),
            actualWidth: this.unitWidth // 添加实际宽度用于样式计算
          })

          current.add(1, 'day')
        }
      } else { // day
        // 日视图：显示日期 - 优化显示逻辑
        const current = start.clone()
        while (current.isSameOrBefore(end, 'day')) {
          const isWeekend = current.day() === 0 || current.day() === 6

          // 根据日期宽度选择合适的标签格式，避免重叠
          let label = ''

          if (this.unitWidth >= 50) {
            label = current.format('MM/DD') // 月/日格式：01/15
          } else if (this.unitWidth >= 30) {
            label = current.format('DD') // 日期：15
          } else if (this.unitWidth >= 20) {
            label = current.format('D') // 简短日期：15
          } else if (this.unitWidth >= 12) {
            // 每2天显示一次
            if (current.date() % 2 === 1) {
              label = current.format('D')
            }
          } else {
            // 每3天显示一次
            if (current.date() % 3 === 1) {
              label = current.format('D')
            }
          }

          periods.push({
            key: current.format('YYYY-MM-DD'),
            label,
            width: this.unitWidth,
            isToday: current.isSame(today, 'day'),
            isWeekend,
            date: current.format('YYYY-MM-DD'),
            actualWidth: this.unitWidth
          })

          current.add(1, 'day')
        }
      }

      return periods
    }
  },

  methods: {
    // 修复日期对齐问题 - 确保日期计算与任务条对齐
    getDatePosition(date) {
      const startOfDay = moment(date).startOf('day')
      const startOfStartDate = moment(this.startDate).startOf('day')
      const daysDiff = startOfDay.diff(startOfStartDate, 'days')
      return daysDiff * this.unitWidth
    },

    // 更新实际宽度
    updateActualWidth() {
      if (this.$refs.timelineContainer) {
        const width = this.$refs.timelineContainer.clientWidth
        if (width > 100) {
          this.actualWidth = width
        } else if (this.$refs.timelineContainer.parentElement) {
          const parentWidth = this.$refs.timelineContainer.parentElement.clientWidth
          if (parentWidth > 100) {
            this.actualWidth = parentWidth
          }
        }
      }
    },

    // 更新时间轴日期范围
    updateTimelineRange(startDate, endDate) {
      // 由于时间轴组件是响应式的，只需触发重新渲染
      // 这个方法主要是为了提供一个接口，让父组件可以通知时间轴更新
      this.$nextTick(() => {
        this.updateActualWidth()
        // 强制重新渲染
        this.$forceUpdate()
      })
    }
  },

  mounted() {
    // 初始化实际宽度
    this.$nextTick(() => {
      this.updateActualWidth()
    })

    // 监听窗口大小变化，重新计算
    this.handleResize = () => {
      this.updateActualWidth()
    }
    window.addEventListener('resize', this.handleResize)
  },

  beforeDestroy() {
    if (this.handleResize) {
      window.removeEventListener('resize', this.handleResize)
    }
  },

  watch: {
    containerWidth: {
      handler(newWidth) {
        if (newWidth && newWidth > 100) {
          this.actualWidth = newWidth
        }
      },
      immediate: true
    },
    // 监听日期范围变化，确保时间轴正确更新
    startDate: {
      handler() {
        // 当开始日期变化时，强制重新计算所有位置
        this.$nextTick(() => {
          this.updateActualWidth()
        })
      },
      deep: true
    },
    endDate: {
      handler() {
        // 当结束日期变化时，强制重新计算所有位置
        this.$nextTick(() => {
          this.updateActualWidth()
        })
      },
      deep: true
    }
  }
}
</script>

<style scoped>
.gantt-timeline {
  position: relative;
  background: #ffffff;
  border-bottom: 1px solid #e1e8ed;
  user-select: none;
  width: 100%;
  min-width: 100%;
  overflow: hidden;
  /* DHTMLX风格：简洁白色背景 */
}

.timeline-scale-top,
.timeline-scale-bottom {
  display: flex;
  width: 100%;
  min-width: 100%;
  background: inherit;
  box-sizing: border-box;
}

.timeline-scale-top {
  height: 32px;
  background: #f8f9fa;
  color: #374151;
  font-weight: 600;
  border-bottom: 1px solid #e1e8ed;
  /* DHTMLX风格：浅灰色背景，深灰色文字 */
}

.timeline-scale-bottom {
  height: 28px;
  background: #ffffff;
  color: #6b7280;
  font-weight: 500;
  /* DHTMLX风格：白色背景，中等灰色文字 */
}

.scale-item {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: background-color 0.2s ease;
  background: inherit;
  flex-shrink: 0;
  position: relative;
  box-sizing: border-box;
  outline: none;
  border: none;
  padding: 0;
  margin: 0;
}

.scale-item::after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 1px;
  background: #e1e8ed;
  pointer-events: none;
  /* DHTMLX风格：统一的边框颜色 */
}

.timeline-scale-bottom .scale-item::after {
  background: #f0f3f6;
  /* 更浅的分隔线 */
}

.timeline-scale-bottom .scale-item {
  font-size: 11px;
  min-height: 28px;
}

.scale-item.is-today {
  background: rgba(74, 144, 226, 0.08) !important;
  color: #4a90e2 !important;
  font-weight: 700;
  z-index: 10;
  /* DHTMLX蓝色主题 */
}

.scale-item.is-today::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(74, 144, 226, 0.05);
  border-left: 2px solid #4a90e2;
  border-right: 2px solid #4a90e2;
  pointer-events: none;
}

.scale-item.is-weekend {
  background: rgba(107, 114, 128, 0.04);
  color: #9ca3af;
  /* 更淡的周末颜色 */
}

.scale-item.is-month-start {
  background: rgba(74, 144, 226, 0.06) !important;
  color: #4a90e2 !important;
  font-weight: 600;
  z-index: 5;
  /* 统一使用DHTMLX蓝色 */
}

.scale-item.is-month-start::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-left: 2px solid #4a90e2;
  background: rgba(74, 144, 226, 0.03);
  pointer-events: none;
}

.timeline-scale-top .scale-item {
  font-weight: 600;
  text-shadow: none;
  /* 移除文字阴影，保持简洁 */
}

.scale-item:hover {
  background-color: rgba(74, 144, 226, 0.08);
  color: #4a90e2;
  /* DHTMLX悬停效果 */
}

.scale-item.is-today:hover {
  background: rgba(74, 144, 226, 0.12) !important;
}

@media (max-width: 768px) {
  .scale-item {
    font-size: 10px;
  }

  .timeline-scale-bottom .scale-item {
    font-size: 9px;
  }

  .timeline-scale-top {
    height: 28px;
  }

  .timeline-scale-bottom {
    height: 24px;
  }
}

.scale-item:empty::after {
  background: transparent;
}

.scale-item[style*="width: 1px"],
.scale-item[style*="width: 2px"],
.scale-item[style*="width: 3px"] {
  font-size: 0;
  padding: 0;
}

.scale-item[style*="width: 1px"]::after,
.scale-item[style*="width: 2px"]::after,
.scale-item[style*="width: 3px"]::after {
  display: none;
}

.gantt-timeline::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: inherit;
  z-index: -1;
}

.scale-item.is-today.is-month-start {
  background: linear-gradient(45deg,
    rgba(74, 144, 226, 0.08) 0%,
    rgba(74, 144, 226, 0.08) 50%,
    rgba(74, 144, 226, 0.06) 50%,
    rgba(74, 144, 226, 0.06) 100%) !important;
}

.scale-item.is-today.is-month-start::before {
  border-left: 2px solid #4a90e2;
  border-right: 2px solid #4a90e2;
}
</style>
