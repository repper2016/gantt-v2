<template>
  <div class="custom-gantt-table">
    <!-- 表格内容（移除表头，使用父组件的时间轴占位） -->
    <div
      class="table-body"
      ref="tableBody"
      @scroll="handleScroll"
    >
      <!-- 表头行 -->
      <div class="table-header-row" :style="{ minWidth: totalTableWidth + 'px' }">
        <!-- 固定左侧列区域 -->
        <div class="fixed-left-columns">
          <!-- 复选框列 -->
          <div class="table-cell checkbox-cell fixed-cell">
            <el-checkbox
              :value="selectAllState === true"
              :indeterminate="selectAllState === 'indeterminate'"
              @change="handleSelectAll"
            />
          </div>

          <!-- 任务名称列 -->
          <div class="table-cell task-name-cell fixed-cell">
            <span class="header-text">Task Name</span>
            <div class="header-actions">
              <i class="el-icon-sort sort-icon" title="Sortable"></i>
            </div>
          </div>
        </div>

        <!-- 滚动区域列 -->
        <div class="scrollable-columns" :style="{ width: scrollableColumnsWidth }">
          <!-- 动态列 -->
          <div
            v-for="column in visibleColumns"
            :key="column.id"
            class="table-cell dynamic-cell scrollable-cell"
            :style="{ width: column.width + 'px' }"
            draggable="true"
            @dragstart="handleColumnDragStart(column, $event)"
            @dragover.prevent
            @drop="handleColumnDrop(column, $event)"
          >
            <span class="header-text">{{ column.label }}</span>
            <div class="header-actions">
              <i class="el-icon-rank drag-handle" title="Drag to reorder"></i>
            </div>
          </div>
        </div>

        <!-- 固定右侧操作列 -->
        <div class="fixed-right-columns">
          <div class="table-cell action-cell fixed-cell" style="display: flex;justify-content: center;">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-setting"
              @click="$emit('show-column-config')"
              title="Configure Columns"
              class="settings-btn"
            />
          </div>
        </div>
      </div>

      <div
        class="table-content"
        :style="{
          height: maxContentHeight + 'px',
          minWidth: totalTableWidth + 'px'
        }"
      >
                <!-- 表格行 -->
        <div
          v-for="(task, index) in tasks"
          :key="`task-${task.id}`"
          class="table-row data-row"
          :class="{
            highlighted: highlightedRowId === task.id,
            'parent-task': task.children && task.children.length > 0
          }"
          :style="{ top: index * 40 + 'px' }"
          @click="handleRowClick(task)"
        >
          <!-- 固定左侧列区域 -->
          <div class="fixed-left-columns">
            <!-- 复选框列 -->
            <div class="table-cell checkbox-cell fixed-cell">
              <el-checkbox
                :value="isTaskSelected(task.id)"
                @change="handleTaskSelect(task.id, $event)"
                @click.stop
              />
            </div>

            <!-- 任务名称列 -->
            <div class="table-cell task-name-cell fixed-cell">
              <div
                class="task-name-content"
                :style="{ paddingLeft: (task.level * 20 + 16) + 'px' }"
              >
                <!-- 折叠/展开按钮 -->
                <button
                  v-if="task.children && task.children.length > 0"
                  class="collapse-btn"
                  :class="{ 'collapsed': isTaskCollapsed(task.id) }"
                  @click.stop="handleToggleCollapse(task.id)"
                >
                  <span class="collapse-icon">
                    {{ isTaskCollapsed(task.id) ? '▶' : '▼' }}
                  </span>
                </button>

                <!-- 任务名称区域 -->
                <div class="task-text-area">
                  <span class="task-name" :title="task.name">{{ task.name }}</span>

                  <!-- 子任务数量 -->
                  <span
                    v-if="task.children && task.children.length > 0"
                    class="children-count"
                  >
                    ({{ task.children.length }})
                  </span>
                </div>
              </div>
            </div>
          </div>

          <!-- 滚动区域列 -->
          <div class="scrollable-columns" :style="{ width: scrollableColumnsWidth }">
            <!-- 动态列 -->
            <div
              v-for="column in visibleColumns"
              :key="column.id"
              class="table-cell dynamic-cell scrollable-cell"
              :style="{ width: column.width + 'px' }"
            >
              <!-- 进度列 -->
              <div v-if="column.id === 'progress'" class="progress-content">
                <div class="progress-bar">
                  <div
                    class="progress-fill"
                    :style="{
                      width: task.progress + '%',
                      backgroundColor: task.color || '#3498db'
                    }"
                  ></div>
                </div>
                <span class="progress-text">{{ task.progress }}%</span>
              </div>

              <!-- 日期列 -->
              <span
                v-else-if="column.id === 'startDate' || column.id === 'endDate' || column.id === 'planStartDate' || column.id === 'planEndDate'"
                class="date-text"
                :class="{ 'plan-date': column.id.startsWith('plan') }"
              >
                {{ formatDate(task[column.prop]) }}
              </span>

              <!-- 状态列 -->
              <span
                v-else-if="column.id === 'status'"
                class="status-badge"
                :class="getStatusClass(task)"
              >
                {{ getTaskStatus(task) }}
              </span>

              <!-- 其他列 -->
              <span v-else>{{ task[column.prop] || '-' }}</span>
            </div>
          </div>

          <!-- 固定右侧操作列 -->
          <div class="fixed-right-columns">
            <div class="table-cell action-cell fixed-cell">
              <el-dropdown trigger="click" size="mini" :append-to-body="true">
                <el-button size="mini" type="text" icon="el-icon-more" />
                <el-dropdown-menu slot="dropdown">
                  <!-- 编辑任务 - 需要检查权限 -->
                  <el-dropdown-item
                    @click.native="$emit('edit-task', task)"
                    :disabled="!hasPermission(task, 'editable')"
                  >
                    <i class="el-icon-edit"></i> Edit Task
                    <span v-if="!hasPermission(task, 'editable')" class="permission-hint">(无权限)</span>
                  </el-dropdown-item>
                  <!-- 添加兄弟任务 - 需要检查权限 -->
                  <el-dropdown-item
                    @click.native="addSiblingTask(task)"
                    divided
                    :disabled="!hasPermission(task, 'editable')"
                  >
                    <i class="el-icon-plus"></i> Add Sibling Task
                    <span v-if="!hasPermission(task, 'editable')" class="permission-hint">(无权限)</span>
                  </el-dropdown-item>
                  <!-- 添加子任务 - 需要检查权限 -->
                  <el-dropdown-item
                    @click.native="addChildTask(task)"
                    :disabled="!hasPermission(task, 'editable')"
                  >
                    <i class="el-icon-circle-plus-outline"></i> Add Child Task
                    <span v-if="!hasPermission(task, 'editable')" class="permission-hint">(无权限)</span>
                  </el-dropdown-item>
                  <!-- 删除任务 - 需要检查删除权限 -->
                  <el-dropdown-item
                    @click.native="$emit('delete-task', task)"
                    divided
                    :disabled="!hasPermission(task, 'deletable')"
                  >
                    <i class="el-icon-delete"></i> Delete Task
                    <span v-if="!hasPermission(task, 'deletable')" class="permission-hint">(无权限)</span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import moment from 'moment'
import Sortable from 'sortablejs'

export default {
  name: 'CustomGanttTable',
  props: {
    tasks: {
      type: Array,
      default: () => []
    },
    highlightedRowId: {
      type: [String, Number],
      default: null
    },
    tableHeight: {
      type: Number,
      default: 400
    }
  },
  data() {
    return {
      draggedColumn: null,
      sortableInstance: null,
      resizeObserver: null
    }
  },
  computed: {
    ...mapState(['selectAllState']),
    ...mapGetters(['isTaskSelected', 'isTaskCollapsed']),

    // 过滤动态列，排除checkbox和taskName
    visibleColumns() {
      return this.$store.getters.visibleColumns.filter(col =>
        col.id !== 'checkbox' && col.id !== 'taskName'
      )
    },

    // 计算表格总宽度
    totalTableWidth() {
      let width = 60 + 200 + 50 // checkbox(60) + taskName(200) + action(50)
      this.visibleColumns.forEach(col => {
        width += col.width || 120
      })
      return width
    },

    // 计算滚动区域宽度
    scrollableColumnsWidth() {
      let width = 0
      this.visibleColumns.forEach(col => {
        width += col.width || 120
      })
      return `${width  }px`
    },

    // 计算表格内容高度
    contentHeight() {
      // 表格内容高度应该根据任务数量动态计算
      // 每行40px高度 + 额外的缓冲空间
      return Math.max(this.tasks.length * 40, 200)
    },

    // 计算实际表格高度 - 直接使用父组件传入的高度
    actualTableHeight() {
      // 父组件已经计算好可用高度，直接使用即可
      // 表头使用sticky定位，不占用内容滚动空间
      return Math.max(this.tableHeight, 200)
    },

    // 计算内容容器的最大高度
    maxContentHeight() {
      // 内容区域的最大高度应该精确匹配任务数量
      // 不添加额外的缓冲空间，确保与甘特图右侧一致
      return Math.max(this.tasks.length * 40, 200)
    }
  },
  watch: {
    // 监听tasks变化，自动更新
    tasks: {
      handler() {
        this.$forceUpdate()
      },
      deep: true
    },
    // 监听tableHeight变化，重新计算表格高度
    tableHeight: {
      handler(newHeight, oldHeight) {
        if (newHeight !== oldHeight) {
          this.$nextTick(() => {
            this.updateTableHeight()
          })
        }
      },
      immediate: true
    }
  },
  methods: {
    ...mapActions(['toggleTaskSelection', 'toggleSelectAll', 'updateColumnOrder']),

    // 格式化日期
    formatDate(date) {
      if (!date) return '-'
      return moment(date).format('MM/DD/YYYY')
    },

    // 获取任务状态
    getTaskStatus(task) {
      if (!task.progress) return 'Not Started'
      if (task.progress >= 100) return 'Completed'
      if (task.progress > 0) return 'In Progress'
      return 'Not Started'
    },

    // 获取状态样式类
    getStatusClass(task) {
      const status = this.getTaskStatus(task)
      return {
        'status-completed': status === 'Completed',
        'status-progress': status === 'In Progress',
        'status-not-started': status === 'Not Started'
      }
    },

    // 处理行点击
    handleRowClick(task) {
      this.$emit('row-click', task)
    },

    // 处理任务选择
    handleTaskSelect(taskId, selected) {
      this.toggleTaskSelection(taskId)
    },

    // 处理全选
    handleSelectAll(selected) {
      this.toggleSelectAll()
    },

    // 处理折叠展开
    handleToggleCollapse(taskId) {
      // 只传播事件给父组件，不要在这里调用store action
      // 父组件会处理store action
      this.$emit('toggle-collapse', taskId)

      // 延迟强制更新，确保store变化后重新渲染
      this.$nextTick(() => {
        this.$forceUpdate()
      })
    },

    // 处理滚动
    handleScroll(event) {
      this.$emit('scroll', event)
    },

    // 处理列拖拽开始
    handleColumnDragStart(column, event) {
      this.draggedColumn = column
      event.dataTransfer.setData('text/plain', column.id)
    },

    // 处理列拖拽放置
    handleColumnDrop(targetColumn, event) {
      event.preventDefault()
      if (!this.draggedColumn || this.draggedColumn.id === targetColumn.id) {
        return
      }

      const draggedIndex = this.visibleColumns.findIndex(col => col.id === this.draggedColumn.id)
      const targetIndex = this.visibleColumns.findIndex(col => col.id === targetColumn.id)

      if (draggedIndex !== -1 && targetIndex !== -1) {
        // 调整索引，加上固定列的偏移
        const actualDraggedIndex = draggedIndex + 2 // +2 因为前面有checkbox和taskName列
        const actualTargetIndex = targetIndex + 2

        this.updateColumnOrder({
          oldIndex: actualDraggedIndex,
          newIndex: actualTargetIndex
        })

        this.$emit('column-reorder')
      }

      this.draggedColumn = null
    },

    // 滚动到指定位置
    scrollTo(top) {
      if (this.$refs.tableBody) {
        this.$refs.tableBody.scrollTop = top
      }
    },

    // 滚动到指定行
    scrollToRow(rowIndex) {
      if (this.$refs.tableBody && rowIndex >= 0 && rowIndex < this.tasks.length) {
        const rowTop = rowIndex * 40 // 每行40px高度
        const containerHeight = this.$refs.tableBody.clientHeight
        const targetScrollTop = Math.max(0, rowTop - containerHeight / 2 + 20) // 居中显示，稍微偏上一点

        this.$refs.tableBody.scrollTo({
          top: targetScrollTop,
          behavior: 'smooth'
        })
      }
    },

    // 获取当前滚动位置
    getScrollTop() {
      return this.$refs.tableBody ? this.$refs.tableBody.scrollTop : 0
    },

    // 更新表格高度
    updateTableHeight() {
      this.$nextTick(() => {
        this.$forceUpdate()
      })
    },



    // 添加同级任务
    addSiblingTask(task) {
      // 发送添加同级任务的事件
      this.$emit('add-sibling-task', task)

      // 显示成功提示
      this.$message({
        message: `正在添加"${task.name}"的同级任务...`,
        type: 'info',
        duration: 1500
      })
    },

    // 添加子任务
    addChildTask(task) {
      // 发送添加子任务的事件
      this.$emit('add-child-task', task)

      // 显示成功提示
      this.$message({
        message: `正在添加"${task.name}"的子任务...`,
        type: 'info',
        duration: 1500
      })
    },

        // 检查任务权限 - 左侧表格和右侧节点每一行都需要有编辑权限控制
    hasPermission(task, permission) {
      // 防止 undefined 错误：安全检查任务对象
      if (!task || typeof task !== 'object') {
        console.warn('hasPermission: 任务对象无效', task)
        return true // 默认允许操作（向后兼容）
      }

      // 如果任务没有权限配置，默认允许所有操作（向后兼容）
      if (!task.permissions || typeof task.permissions !== 'object') {
        return true
      }

      // 检查具体权限
      return task.permissions[permission] === true
    }
  },
  mounted() {
    // 监听外部滚动事件
    this.$emit('table-mounted', this)

    // 确保在组件挂载后更新高度 - 多重保护机制
    this.$nextTick(() => {
      this.updateTableHeight()

      // 延迟再次更新，确保DOM完全渲染
      setTimeout(() => {
        this.updateTableHeight()
      }, 100)
    })

    // 监听窗口大小变化
    this.resizeObserver = new ResizeObserver(() => {
      this.updateTableHeight()
    })

    if (this.$refs.tableBody) {
      this.resizeObserver.observe(this.$refs.tableBody)
    }
  },

  beforeDestroy() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect()
    }
  }
}
</script>

<style scoped>
/* ===== 表格容器 ===== */
.custom-gantt-table {
  height: 100%;
  width: 100%;
  overflow: hidden;
  background: #ffffff;
  border-right: 1px solid #e1e8ed;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
  /* DHTMLX风格：简洁白色背景和细边框 */
}

.table-body {
  overflow: auto;
  width: 100%;
  background: #ffffff;
  position: relative;
  /* 确保表格容器有正确的高度以便滚动 */
  height: 100%;
}

/* ===== 表头样式 ===== */
.table-header-row {
  position: sticky;
  top: 0;
  z-index: 100;
  background: #f8f9fa;
  border-bottom: 1px solid #e1e8ed;
  display: flex;
  height: 62px;
  font-weight: 600;
  font-size: 13px;
  color: #374151;
  /* DHTMLX风格：浅灰色背景，深灰色文字，与右侧甘特图时间轴高度一致 */
}

.table-cell {
  display: flex;
  align-items: center;
  padding: 0 10px;
  border-right: 1px solid #f0f3f6;
  border-bottom: 1px solid #eee;
  background: inherit;
  box-sizing: border-box;
  min-height: 62px;
  height: 62px;
  /* 表头单元格高度与表头行保持一致 */
}

/* 数据行中的单元格需要单独设置高度 */
.data-row .table-cell {
  min-height: 40px;
  height: 40px;
  /* 数据行单元格高度与数据行对齐 */
}

.fixed-cell {
  background: #f8f9fa;
  z-index: 10;
  /* 固定列保持表头背景色 */
}

.header-text {
  flex: 1;
  font-weight: 600;
  color: #374151;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.header-actions {
  margin-left: 8px;
  display: flex;
  gap: 4px;
}

.sort-icon,
.drag-handle {
  color: #9ca3af;
  cursor: pointer;
  font-size: 14px;
  transition: color 0.2s ease;
}

.sort-icon:hover,
.drag-handle:hover {
  color: #4a90e2;
  /* DHTMLX蓝色悬停效果 */
}

/* ===== 表格内容区域 ===== */
.table-content {
  position: relative;
  width: 100%;
}

.table-row {
  position: absolute;
  width: 100%;
  display: flex;
  border-bottom: 1px solid #f0f3f6;
  transition: background-color 0.15s ease;
  cursor: pointer;
  /* 确保与甘特图节点对齐 - 精确匹配甘特图行高 */
  height: 40px;
  line-height: 40px;
  box-sizing: border-box;
  /* 添加对齐基线 */
  align-items: center;
}

.data-row {
  background: #ffffff;
  min-height: 40px;
  height: 40px;
  /* 确保行高一致，与甘特图节点完全对齐 */
}

/* 行选中状态 - 优化视觉效果，移除边框避免被覆盖 */
.table-row.highlighted {
  background: rgba(74, 144, 226, 0.15) !important;
  position: relative;
  z-index: 50;
  /* 移除border，使用背景色和伪元素实现高亮效果 */
}

.table-row.highlighted::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(90deg, rgba(74, 144, 226, 0.12) 0%, rgba(74, 144, 226, 0.08) 100%);
  pointer-events: none;
  z-index: 999;
  /* 确保高亮背景在最顶层，避免被其他元素覆盖 */
}

.table-row.highlighted::after {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: #4a90e2;
  pointer-events: none;
  /* 使用伪元素实现左侧指示条 */
}

/* 行悬停效果 */
.table-row:hover {
  background: #f8f9fa;
}

.table-row.highlighted:hover {
  background: rgba(74, 144, 226, 0.18) !important;
}

.data-row.even-row {
  background: #ffffff;
}

.data-row.odd-row {
  background: #fafbfc;
  /* 轻微的斑马条纹效果 */
}

.data-row.parent-row {
  background: #f8f9fa;
  font-weight: 600;
  border-bottom: 1px solid #e1e8ed;
  /* 父节点使用更深的背景色 */
}

.data-row.parent-row:hover {
  background: #f1f3f4;
}

/* ===== 任务名称列优化 ===== */
.task-name-cell {
  min-width: 180px;
  max-width: 250px;
  width: 200px;
  flex: 0 0 200px;
  /* 固定列宽 */
}

.task-name-content {
  display: flex;
  align-items: center;
  width: 100%;
  gap: 6px;
  height: 100%;
  justify-content: space-between;
  /* 确保内容垂直居中，任务文本和操作按钮分别在两端 */
}

.collapse-btn {
  background: none;
  border: none;
  padding: 2px 4px;
  cursor: pointer;
  color: #6b7280;
  border-radius: 2px;
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  flex-shrink: 0;
}

.collapse-btn:hover {
  background: #e5e7eb;
  color: #374151;
}

.collapse-icon {
  font-size: 10px;
  transition: transform 0.15s ease;
}

.collapse-btn.collapsed .collapse-icon {
  transform: rotate(0deg);
}

.task-name {
  font-weight: 500;
  color: #374151;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 13px;
  line-height: 1.2;
  min-width: 0;
  flex: 1;
  /* 确保文本能够正确省略 */
}

.children-count {
  color: #9ca3af;
  font-size: 11px;
  font-weight: 400;
  background: #f3f4f6;
  padding: 1px 6px;
  border-radius: 10px;
}

/* ===== 复选框列 ===== */
.checkbox-cell {
  width: 50px;
  justify-content: center;
  background: #f8f9fa;
  border-right: 1px solid #e1e8ed;
}

/* Element UI复选框样式重写 */
.checkbox-cell .el-checkbox__input.is-checked .el-checkbox__inner {
  background-color: #4a90e2;
  border-color: #4a90e2;
  /* DHTMLX蓝色主题 */
}

.checkbox-cell .el-checkbox__inner:hover {
  border-color: #4a90e2;
}

/* ===== 操作列 ===== */
.action-cell {
  width: 60px;
  justify-content: center;
  background: #f8f9fa;
  border-left: 1px solid #e1e8ed;
}

.settings-btn {
  color: #6b7280 !important;
  font-size: 16px !important;
  padding: 4px !important;
  border: none !important;
  background: none !important;
}

.settings-btn:hover {
  color: #4a90e2 !important;
  background: rgba(74, 144, 226, 0.1) !important;
}

/* ===== 进度条样式 ===== */
.progress-content {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}

.progress-bar {
  flex: 1;
  height: 6px;
  background: #f3f4f6;
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: #4a90e2;
  border-radius: 3px;
  transition: width 0.3s ease;
  /* DHTMLX蓝色进度条 */
}

.progress-text {
  font-size: 11px;
  color: #6b7280;
  font-weight: 500;
  min-width: 35px;
  text-align: right;
}

/* ===== 状态标签 ===== */
.status-badge {
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 600;
  text-align: center;
  white-space: nowrap;
}

/* ===== 权限控制样式 ===== */
.permission-hint {
  color: #f56c6c;
  font-size: 10px;
  margin-left: 4px;
  font-style: italic;
  /* 权限提示样式 */
}

.status-badge.not-started {
  background: #f3f4f6;
  color: #6b7280;
}

.status-badge.in-progress {
  background: rgba(74, 144, 226, 0.1);
  color: #4a90e2;
}

.status-badge.completed {
  background: rgba(34, 197, 94, 0.1);
  color: #22c55e;
}

.status-badge.overdue {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}

/* ===== 日期文本样式 ===== */
.date-text {
  font-size: 12px;
  color: #6b7280;
}

.date-text.plan-date {
  color: #4a90e2;
  font-style: italic;
}

/* ===== 滚动区域样式 ===== */
.scrollable-columns {
  display: flex;
  overflow: hidden;
}

.fixed-left-columns,
.fixed-right-columns {
  display: flex;
  position: sticky;
  z-index: 10;
}

.fixed-left-columns {
  left: 0;
  background: #f8f9fa;
}

.fixed-right-columns {
  right: 0;
  background: #f8f9fa;
}

/* ===== 滚动条样式 ===== */
.table-body::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-body::-webkit-scrollbar-track {
  background: #f8f9fa;
}

.table-body::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 4px;
}

.table-body::-webkit-scrollbar-thumb:hover {
  background: #9ca3af;
}

/* ===== 响应式优化 ===== */
@media (max-width: 768px) {
  .table-cell {
    padding: 0 8px;
  }

  .task-name-cell {
    min-width: 150px;
  }

  .header-text,
  .task-name {
    font-size: 12px;
  }
}

/* ===== 任务悬停操作菜单 ===== */
.task-name-content {
  position: relative;
}

/* 任务文本区域 */
.task-text-area {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
  /* 允许文本压缩，为操作按钮预留空间 */
}

.task-hover-actions {
  display: flex;
  gap: 4px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 4px;
  padding: 2px 4px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
  z-index: 100;
  animation: fadeIn 0.2s ease;
  border: 1px solid rgba(0, 0, 0, 0.05);
  flex-shrink: 0;
  /* 操作按钮不压缩，始终保持原尺寸 */
}

.task-action-btn {
  width: 24px;
  height: 24px;
  border-radius: 3px;
  border: none;
  background: #f3f4f6;
  color: #6b7280;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  padding: 0;
  position: relative;
  font-size: 12px;
}

.task-action-btn:hover {
  background: #4a90e2;
  color: white;
  transform: translateY(-2px);
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.task-action-btn:hover::after {
  content: attr(title);
  position: absolute;
  bottom: -25px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 3px 8px;
  border-radius: 3px;
  font-size: 11px;
  white-space: nowrap;
  z-index: 101;
}

.edit-btn:hover {
  background: #22c55e;
}

.add-sibling-btn:hover {
  background: #3b82f6;
}

.add-child-btn:hover {
  background: #8b5cf6;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-50%) translateX(10px);
  }
  to {
    opacity: 1;
    transform: translateY(-50%) translateX(0);
  }
}
</style>
