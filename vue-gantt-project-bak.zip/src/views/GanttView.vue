<template>
  <div class="gantt-view">
    <!-- 甘特图表格区域 -->
    <div class="gantt-section">
      <!-- 始终使用主要的GanttChart组件，不受vis-timeline配置影响 -->
            <GanttChart
        :data="ganttData"
        :tooltip-enabled.sync="tooltipEnabled"
        :tooltip-delay="tooltipDelay"
        :tooltip-hide-delay="tooltipHideDelay"
        :timeline-visible="timelineVisible"
        :show-settings-dialog="showSettingsDialog"
        @update:showSettingsDialog="$emit('update:showSettingsDialog', $event)"
        :current-view-mode="currentViewMode"
        @settings-dialog-close="handleSettingsClose"
        @view-mode-change="handleViewModeChange"
      />
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import GanttChart from '../components/GanttChart.vue'

export default {
  name: 'GanttView',
  components: {
    GanttChart
  },
  props: {
    timelineVisible: {
      type: Boolean,
      default: true
    },
    showSettingsDialog: {
      type: Boolean,
      default: false
    },
    currentViewMode: {
      type: String,
      default: 'month'
    }
  },
  data() {
    return {
      // Tooltip配置
      tooltipEnabled: true,  // 默认不显示tooltip
      tooltipDelay: 1000,     // 1秒后显示
      tooltipHideDelay: 300   // 300ms后隐藏
    }
  },
  computed: {
    ...mapState(['ganttData'])
  },
  methods: {
    // 处理设置对话框关闭
    handleSettingsClose() {
      this.$emit('settings-dialog-close')
    },
    // 处理视图模式变化
    handleViewModeChange(mode) {
      console.log('[调试] GanttView 接收到视图模式变化:', mode)
      this.$emit('view-mode-change', mode)
    }
  }
}
</script>

<style scoped>
.gantt-view {
  flex: 1;
  display: flex;
  flex-direction: column;
  height: calc(100vh - 80px);
  overflow-x: visible;
  overflow-y: hidden;
}

.gantt-section {
  flex: 1;
  min-height: 0;
  height: 100%;
}
</style>
